$(document).ready(function(){
window.serverURL = "http://localhost/finalproject/server_side/ws/";


 function allinvisible(){
   $("#users").addClass("displaytablenone");
   $("#cartable").addClass("displaytablenone");
   $("#reservations").addClass("displaytablenone");
   $("#brands").addClass("displaytablenone");
   $("#categories").addClass("displaytablenone");
   $("#dashboardstatistics").addClass("displaytablenone");
   $("#ModalLong").remove();
 }

 function filtercardivs(){

 }

allinvisible();

// View Cars
$("#viewcars").on("click",function(){

  if($("#cartable").hasClass("displaytablenone")){
  allinvisible();
  $("#cartable").toggleClass("displaytablenone");
  getCars();
}

});

// View Users
$("#viewusers").on("click",function(){

if($("#users").hasClass("displaytablenone")){
  allinvisible();
  $("#users").toggleClass("displaytablenone");
  getUsers();
}

});

// View Reservations
$("#viewsold").on("click",function(){

  if($("#reservations").hasClass("displaytablenone")){
  allinvisible();
  $("#reservations").toggleClass("displaytablenone");
  getReservations();
}

});

// View Brands
$("#viewbrands").on("click",function(){
  if($("#brands").hasClass("displaytablenone")){
  allinvisible();
  $("#brands").toggleClass("displaytablenone");
  getBrands();
}
});

// View Categories
$("#viewcategories").on("click",function(){

  if($("#categories").hasClass("displaytablenone")){
  allinvisible();
  $("#categories").toggleClass("displaytablenone");
  getCategories();
}

});

// View Dashboard And Statistics
$("#viewstatistics").on("click",function(){
if($("#dashboardstatistics").hasClass("displaytablenone")){
  allinvisible();
  $("#dashboardstatistics").toggleClass("displaytablenone");

}

});

// Inactive Users
$(document).on('click','[id^=userdel]',function(){
		id = this.id.substring(7);

		setuserinactive(id);

   });

// Inactive Cars
$(document).on('click','[id^=carsdel]',function(){
		id = this.id.substring(7);

		setcarinactive(id);

   });

// Inactive Brands
$(document).on('click','[id^=brandsdel]',function(){
		id = this.id.substring(9);

		setbrandinactive(id);

   });

// InActive Categories
$(document).on('click','[id^=categoriesdel]',function(){
		id = this.id.substring(13);

		setcategoryinactive(id);

   });

// Update User
$(document).on('click','[id^=user]',function(){
		id = this.id.substring(4);

		getcurrentuserandmodify(id);

   });

// Update Car
$(document).on("click","[id^=cars]",function(){
  id=this.id.substring(4);

  getcurrentcarandmodify(id);
});

// Update Brand
$(document).on("click","[id^=brands]",function(){
  id=this.id.substring(6);

  getcurrentbrandmodify(id);
});

// Update Category
$(document).on("click","[id^=categories]",function(){
  id=this.id.substring(10);

  getcurrentcategorymodify(id);
});

// Update Sale
$(document).on("click","[id^=sales]",function(){
  id=this.id.substring(4);

  getcurrentsalemodify(id);
});

   // Apply User Change
      $(document).on("click","#applyuserchange",function(){
        modaldialogupdateuser();
      });

// Apply Car Change
  $(document).on("click","#applycarchange",function(){
    modaldialogupdatecar();
  });

  // Apply Brand Change
    $(document).on("click","#applybrandchange",function(){
      modaldialogupdatebrand();
    });

    // Apply Category Change
      $(document).on("click","#applycategorychange",function(){
        modaldialogupdatecategory();
      });

// Get All Users
function getUsers(){

		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_users.php",
			  data: ({option :"4"}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data==0)
					  alert("Data couldn't be loaded!")
				  else{
				  	data = JSON.parse(xhr.responseText);

					populateUsersTable(data);
				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}

function populateUsersTable(data){

		//data = data.users;
		var item;

		$("#users tbody").empty();

		if(data.length>0){

		   $.each(data, function(index, row) {

			  item=  "<tr>";
			  item+= "<td>"+row.FirstName+"</td>";
  			item+= "<td>"+row.LastName+"</td>";
  			item+= "<td>"+row.Phone+"</td>";
        item+= "<td>"+row.Email+"</td>";
        item+= "<td>"+row.Username+"</td>";
        item+= "<td>"+row.Status+"</td>";
        item+= "<td>"+row.Position+"</td>";
			  item+= "<td class='modification'><a class='update' href='#' data-toggle='modal' data-target='#ModalLong' id='user"+row.ID+"'><i class='fas fa-wrench'></i></a> <a class='delete' href='#' id='userdel"+row.ID+"'> <i class='fas fa-trash-alt'></i></a></td>";
			  item+= "</tr>";

		 	$("#users").append(item);

			});

// MultiLine Input
      var item2;
      item2=`<!-- Link "a" Tag Button trigger modal -->

                    <!-- Modal -->
                    <div class="modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                                <label>First Name</label>
                              <input id="modalfname" type="text" class="col-md-12 form-control"/>
                              <label>Last Name</label>
                              <input id="modallname" type="text" class="col-md-12 form-control"/>
                              <label>Phone</label>
                              <input id="modalphone" type="number" class="col-md-12 form-control"/>
                              <label>Email</label>
                              <input id="modalemail" type="email" class="col-md-12 form-control"/>
                              <label>Username</label>
                              <input id="modalusername" type="text" class="col-md-12 form-control"/>
                              <div class="col-md-12 middelmodalcenter">
                              <div class="col-md-5">
                              <label>Status</label>
                              </div>
                              <div class="col-md-5">
                              <label>Position</label>
                              </div>
                              </div>
                              <div class="col-md-12">
                              <select class="selectoption col-md-5" id="modalstatusoption">
                                <option value="1">Active</option>
                                <option value="0">InActive</option>
                              </select>

                              <select class="selectoption col-md-5 offset-md-1" id="modalpositionoption">
                                <option value="0">Regular</option>
                                <option value="1">Administrator</option>
                              </select>

                              </div>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" data-dismiss="modal" id='applyuserchange'>Save changes</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    `;
      $("#users").append(item2);
		}
	}

// Get All Cars
function getCars(){

		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_cars.php",
			  data: ({option :"1"}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data<=0)
					  alert("Data couldn't be loaded!")
				  else{
				  	data = JSON.parse(xhr.responseText);

					populateCarsTable(data);
				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}

function populateCarsTable(data){

		//data = data.users;
		var item;

		$("#cartable tbody").empty();

		if(data.length>0){

		   $.each(data, function(index, row) {

			  item=  "<tr>";
			  item+= "<td>"+row.Name+"</td>";
  			item+= "<td>"+row.Brand+"</td>";
        item+= "<td>"+row.Category+"</td>";
        item+= "<td>"+row.Year+"</td>";
        item+= "<td>"+row.Color+"</td>";
        item+= "<td>"+row.NumberofSeats+"</td>";
        item+= "<td>"+row.Price+"</td>";
        item+= "<td>"+row.Description+"</td>";
        item+= "<td>"+row.Status+"</td>";
			  item+= "<td class='modification'><a class='update' href='#' data-toggle='modal' data-target='#ModalLong'  id='cars"+row.ID+"'><i class='fas fa-wrench'></i></a> <a class='delete' href='#' id='carsdel"+row.ID+"'> <i class='fas fa-trash-alt'></i></a></td>";
			  item+= "</tr>";

		 	$("#cartable tbody").append(item);

			});

      // MultiLine Input
            var item2;
            item2=`
            <!-- Modal -->
            <div class="modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                      <div class="col-md-12 centeralign"><label>Car Name</label></div>
                      <input id="modalcarname" type="text" class="col-md-12 form-control"/>
                      <div class="col-md-12 middelmodalcenter">
                        <div class="col-md-5"><label>Brand</label></div>
                        <div class="col-md-5 offset-md-1"><label>Category</label></div>
                      </div>
                      <select class="selectoption col-md-5" id="modalcarbrandoption">

                      </select>

                      <select class="selectoption col-md-5 offset-md-1" id="modalcarcategoryoption">

                      </select>
                      <div class="col-md-12 centeralign"><label>Year</label></div>
                      <input id="modalcaryear" type="number" class="col-md-12 form-control"/>
                      <label>Color</label>
                      <input id="modalcarcolor" type="text" class="col-md-12 form-control"/>
                      <label>Number Of Seats</label>
                      <input id="modalcarnumberofseat" type="number" class="col-md-12 form-control"/>
                      <label>Price in Dollars</label>
                      <input id="modalcarprice" type="number" class="col-md-12 form-control"/>
                      <div class="col-md-12"><label>Description</label></div>
                      <textarea rows="8" class="col-md-12" id="modalcardescription">
                      </textarea>
                      <div class="col-md-12 middelmodalcenter">
                      <div class="col-md-12">
                      <label>Status</label>
                      </div>
                      </div>
                      <div class="col-md-12 justify-content-center centeralign">
                      <select class="selectoption col-md-6" id="modalcarstatusoption">
                        <option value="1">Active</option>
                        <option value="0">InActive</option>
                      </select>
                      </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal" id='applycarchange'>Save changes</button>
                  </div>
                </div>
              </div>
            </div>
            `;
            $("#cartable").append(item2);
            getBrandNames();
            getCategoryNames();
		}
	}

  // Reservations
  function getReservations(){

  		  $.ajax({
  			  type: 'GET',
  			  url: window.serverURL+"ws_sales.php",
  			  data: ({option :"1"}),

  			  dataType: 'json',
  			  timeout: 5000,
  			  success: function(data, textStatus, xhr)
  			  {

  				  if(data==0)
  					  alert("Data couldn't be loaded!")
  				  else{
  				  	data = JSON.parse(xhr.responseText);

  					populateReservationsTable(data);
  				  }
  			  },
  			  error: function(xhr, status, errorThrown)
  			  {
  				  alert(status + errorThrown);
  			  }
  		  });  //

  	}

  function populateReservationsTable(data){

  		//data = data.users;
  		var item;

  		$("#reservations tbody").empty();

  		if(data.length>0){

  		   $.each(data, function(index, row) {

  			  item=  "<tr>";
  			  item+= "<td>"+row.Buyer+"</td>";
          item+= "<td>"+row.Name+"</td>";
    			item+= "<td>"+row.Description+"</td>";
          item+= "<td>"+row.Year+"</td>";
          item+= "<td>"+row.Color+"</td>";
          item+= "<td>"+row.Price+"</td>";
    			item+= "<td>"+row.DateBought+"</td>";
  			  item+= "</tr>";

  		 	$("#reservations").append(item);

  			});
  		}
  	}

// Categories
    function getCategories(){

          $.ajax({
            type: 'GET',
            url: window.serverURL+"ws_categories.php",
            data: ({option :"1"}),

            dataType: 'json',
            timeout: 5000,
            success: function(data, textStatus, xhr)
            {

              if(data==0)
                alert("Data couldn't be loaded!")
              else{
                data = JSON.parse(xhr.responseText);

              populateCategoriesTable(data);
              }
            },
            error: function(xhr, status, errorThrown)
            {
              alert(status + errorThrown);
            }
          });  //

      }

    function populateCategoriesTable(data){

        //data = data.users;
        var item;

        $("#categories tbody").empty();

        if(data.length>0){

           $.each(data, function(index, row) {

            item=  "<tr>";
            item+= "<td>"+row.Category+"</td>";
            item+= "<td>"+row.Status+"</td>";
            item+= "<td class='modification'><a class='update' href='#' data-toggle='modal' data-target='#ModalLong' id='categories"+row.ID+"'><i class='fas fa-wrench'></i></a> <a class='delete' href='#' id='categoriesdel"+row.ID+"'> <i class='fas fa-trash-alt'></i></a></td>";
            item+= "</tr>";

          $("#categories tbody").append(item);

          });

          var item2;
          item2=`  <!-- Modal -->
            <div class="modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="col-md-12 centeralign">
                        <label>Category Name</label>
                        </div>
                      <input id="modalcategoryname" type="text" class="col-md-12 form-control"/>
                    <div class="col-md-12 centeralign">
                        <label>Status</label>
                      </div>
                      <div class="col-md-12 centeralign">
                      <select class="selectoption col-md-5" id="modalcategorystatusoption">
                        <option value="1">Active</option>
                        <option value="0">InActive</option>
                      </select>

                      </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal" id='applycategorychange'>Save changes</button>
                  </div>
                </div>
              </div>
            </div>
`;

          $("#categories").append(item2);
        }
      }


// Get Brands
function getBrands(){

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_brands.php",
        data: ({option :"1"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);

          populateBrandsTable(data);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }

function populateBrandsTable(data){

    //data = data.users;
    var item;
    var item2;

    $("#brands tbody").empty();

    if(data.length>0){

       $.each(data, function(index, row) {

        item=  "<tr>";
        item+= "<td>"+row.Name+"</td>";
        item+= "<td>"+row.Status+"</td>";
        item+= "<td class='modification'><a class='update' href='#' data-toggle='modal' data-target='#ModalLong' id='brands"+row.ID+"'><i class='fas fa-wrench'></i></a> <a class='delete' href='#' id='brandsdel"+row.ID+"'> <i class='fas fa-trash-alt'></i></a></td>";
        item+= "</tr>";

      $("#brands").append(item);

      });

// MultiLine Modal
      item2=`  <!-- Modal -->
        <div class="modal fade" id="ModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="col-md-12 centeralign">
                    <label>Brand Name</label>
                    </div>
                  <input id="modalbrandname" type="text" class="col-md-12 form-control"/>
                <div class="col-md-12 centeralign">
                    <label>Status</label>
                  </div>
                  <div class="col-md-12 centeralign">
                  <select class="selectoption col-md-5" id="modalbrandstatusoption">
                    <option value="1">Active</option>
                    <option value="0">InActive</option>
                  </select>

                  </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id='applybrandchange'>Save changes</button>
              </div>
            </div>
          </div>
        </div>
`;

      $("#brands").append(item2);
    }
  }

// Set User InActive
function setuserinactive(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_users.php",
    data: ({option :"7",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);

      getUsers(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Set Cars InActive
function setcarinactive(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_cars.php",
    data: ({option :"4",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);

      getCars(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Set Brands InActive
function setbrandinactive(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_brands.php",
    data: ({option :"4",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);

      getBrands(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Set Categories InActive
function setcategoryinactive(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_categories.php",
    data: ({option :"4",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);

      getCategories(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Get Current User
function getcurrentuserandmodify(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_users.php",
    data: ({option :"10",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        modaldialogmodifyuser(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Modal Modify User
function modaldialogmodifyuser(data){
        try{
            $(".modal-header").text(data[0].ID+" "+data[0].Username)
            $("#modalfname").val(data[0].FirstName);
            $("#modallname").val(data[0].LastName);
            $("#modalphone").val(data[0].Phone);
            $("#modalemail").val(data[0].Email);
            $("#modalusername").val(data[0].Username);
            $("#modalstatusoption").val(data[0].Status);
            $("#modalpositionoption").val(data[0].Position);
          }
          catch(ex){
            console.log(ex);
          }

  }

// Update User
function modaldialogupdateuser(){

          console.log("hi");
            var fname=$("#modalfname").val();
            var lname=$("#modallname").val();
            var phone=$("#modalphone").val();
            var email=$("#modalemail").val();
            var username=$("#modalusername").val();
            var status=$("#modalstatusoption").val();
            var position=$("#modalpositionoption").val();
            var id=parseInt($(".modal-header").text().split(" ")[0]);

            $.ajax({
              type: 'GET',
              url: window.serverURL+"ws_users.php",
              data: ({option :"6",id:id,firstName:fname,lastName:lname,phone:phone,email:email,username:username,admin:position,active:status}),

              dataType: 'json',
              timeout: 5000,
              success: function(data, textStatus, xhr)
              {

                if(data==0)
                  alert("Data couldn't be loaded!")
                else{
                  data = JSON.parse(xhr.responseText);
                  getUsers();
                }
              },
              error: function(xhr, status, errorThrown)
              {
                alert(status + errorThrown);
              }
            });  //


  }

// Get Current Car
function getcurrentcarandmodify(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_cars.php",
    data: ({option :"5",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
        else if(data == null){
          data= [{"ID":"Sold, Access Denied","Brand":"Sold, Access Denied","Category":"Sold, Access Denied","Name":"Sold, Access Denied","Description":"Sold, Access Denied","Year":"0","Color":"Sold, Access Denied","NumberofSeats":"0","Price":"0","Status":"Sold, Access Denied"}]
        modaldialogmodifycarbutsold(data);
      }
      else{
        data = JSON.parse(xhr.responseText);
        modaldialogmodifycar(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Modal Modify Car
function modaldialogmodifycar(data){

        try{
          console.log(data);
            $(".modal-header").text(data[0].ID+" "+data[0].Name)
            $("#modalcarname").val(data[0].Name);
            $("#modalcaryear").val(data[0].Year);
            $("#modalcarcolor").val(data[0].Color);
            $("#modalcarnumberofseat").val(data[0].NumberofSeats);
            $("#modalcarprice").val(data[0].Price);
            $("#modalcardescription").val(data[0].Description);
            $("#modalcarstatusoption").val(data[0].Status);
            $("#modalcarbrandoption").val(data[0].Brand);
            $("#modalcarcategoryoption").val(data[0].Category);
          }
          catch(ex){
            console.log(ex);
          }

  }

// Modal Modify Car Of Sold Car
function modaldialogmodifycarbutsold(data){

        try{
          console.log(data);
            $(".modal-header").text(data[0].ID+" "+data[0].Name)
            $("#modalcarname").val(data[0].Name);
            $("#modalcaryear").val(data[0].Year);
            $("#modalcarcolor").val(data[0].Color);
            $("#modalcarnumberofseat").val(data[0].NumberofSeats);
            $("#modalcarprice").val(data[0].Price);
            $("#modalcardescription").val(data[0].Description);
            $("#modalcarstatusoption").val(data[0].Status);
            $("#modalcarbrandoption").val(data[0].Brand);
            $("#modalcarcategoryoption").val(data[0].Category);
          }
          catch(ex){
            console.log(ex);
          }

  }

// Update Car
function modaldialogupdatecar(){

            var carname =$("#modalcarname").val();
            var year=parseInt($("#modalcaryear").val());
            var color=$("#modalcarcolor").val();
            var numberofseats=parseInt($("#modalcarnumberofseat").val());
            var price=parseInt($("#modalcarprice").val());
            var description=$("#modalcardescription").val();
            var statusoption=parseInt($("#modalcarstatusoption").val());
            var brandoption=parseInt($("#modalcarbrandoption").val());
            var categoryoption=parseInt($("#modalcarcategoryoption").val());
            var id=parseInt($(".modal-header").text().split(" ")[0]);

            $.ajax({
              type: 'GET',
              url: window.serverURL+"ws_cars.php",
              data: ({option :"3",id:id,name:carname,description:description,brand:brandoption,category:categoryoption,year:year,color:color,seats:numberofseats,price:price,active:statusoption}),

              dataType: 'json',
              timeout: 5000,
              success: function(data, textStatus, xhr)
              {
                if(data==0)
                  alert("Data couldn't be loaded!")
                else{
                  data = JSON.parse(xhr.responseText);
                  getCars();
                }
              },
              error: function(xhr, status, errorThrown)
              {
                alert(status + errorThrown);
              }
            });  //


  }

// Get Current Brand
function getcurrentbrandmodify(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_brands.php",
    data: ({option :"6",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        modaldialogmodifybrand(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Modal Modify Brand
function modaldialogmodifybrand(data){

        try{
            $(".modal-header").text(data[0].ID+" "+data[0].Name)
            $("#modalbrandname").val(data[0].Name);
            $("#modalbrandstatusoption").val(data[0].Active);
          }
          catch(ex){
            console.log(ex);
          }

  }

// Update Brand
function modaldialogupdatebrand(){

            var brandname =$("#modalbrandname").val();
            var brandstatus=$("#modalbrandstatusoption").val();
            var id=parseInt($(".modal-header").text().split(" ")[0]);

            $.ajax({
              type: 'GET',
              url: window.serverURL+"ws_brands.php",
              data: ({option :"3",id:id,brand:brandname,active:brandstatus}),

              dataType: 'json',
              timeout: 5000,
              success: function(data, textStatus, xhr)
              {
                if(data==0)
                  alert("Data couldn't be loaded!")
                else{
                  data = JSON.parse(xhr.responseText);
                  getBrands();
                }
              },
              error: function(xhr, status, errorThrown)
              {
                alert(status + errorThrown);
              }
            });  //


  }

// Get Current Category
function getcurrentcategorymodify(id){

  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_categories.php",
    data: ({option :"6",id:id}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        modaldialogmodifycategory(data);
      }
    },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });  //

}

// Modal Modify Category
function modaldialogmodifycategory(data){

        try{
            $(".modal-header").text(data[0].cat_id+" "+data[0].cat_name)
            $("#modalcategoryname").val(data[0].cat_name);
            $("#modalcategorystatusoption").val(data[0].cat_active);
          }
          catch(ex){
            console.log(ex);
          }

  }

// Update Category
function modaldialogupdatecategory(){

            var categoryname =$("#modalcategoryname").val();
            var categorystatus=$("#modalcategorystatusoption").val();
            var id=parseInt($(".modal-header").text().split(" ")[0]);

            $.ajax({
              type: 'GET',
              url: window.serverURL+"ws_categories.php",
              data: ({option :"3",id:id,category:categoryname,active:categorystatus}),

              dataType: 'json',
              timeout: 5000,
              success: function(data, textStatus, xhr)
              {
                if(data==0)
                  alert("Data couldn't be loaded!")
                else{
                  data = JSON.parse(xhr.responseText);
                  getCategories();
                }
              },
              error: function(xhr, status, errorThrown)
              {
                alert(status + errorThrown);
              }
            });  //


  }

// Get Category Names
function getCategoryNames(){
     item4="";

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_categories.php",
        data: ({option :"5"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);
            $.each(data, function(index, row) {
             item4+= "<option value='"+row.cat_id+"'>"+row.cat_name+"</option> ";
           });

           $("#modalcarcategoryoption").append(item4);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //
  }

// Get Brands Names
function getBrandNames(){
     item3="";

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_brands.php",
        data: ({option :"5"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);
            $.each(data, function(index, row) {
             item3+= "<option value='"+row.b_id+"'>"+row.b_name+"</option> ";
           });

             $("#modalcarbrandoption").append(item3);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }


// Graphs For Statistics
// Most Bought Cars
getmostcarviewers();
getmostboughtcars();
getmostbuyingusers();
getSumOfSoldCars();
function getmostboughtcars(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_sales.php",
    data: ({option :"6"}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        getmostboughtcarsdoughnut(data);
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

function getmostboughtcarsdoughnut(data){

//   var data2=[];
//   var carnames=[];
//   var count1,count2,count3,count4,count5;
//   var maxdate;
//
// // Search For Max Date
//   $.each(data, function(index, row) {
//     row.DateBought=row.DateBought.slice(5,7);
//     if(row.ID==1){
//       maxdate=row.DateBought;
//     }
//     else{
//       if(maxdate<=row.DateBought){
//         maxdate=row.DateBought;
//       }
//     }
//  });
//  // Append All The Max Dates
//  $.each(data, function(index, row) {
//    if(maxdate==row.DateBought){
//       data2.push(row);
//    }
// });
// // Maximum Cars Bought By Names
// $.each(data2, function(index, row) {
//   if(carnames.length==0){
//      carnames[row.Name]=1;
//   }
//   else{
//     for(var i=0;i<data2.length;i++){
//
//       if(row.Name==data2[i].Name){
//         carnames[row.Name]+=1;
//       }
//       else if(row.Name!=data2[i].Name){
//         carnames[row.Name]=1;
//       }
//     }
//     // if(!(jQuery.inArray(String(row.Name), carnames)))
//     // {carnames.push(row.Name);}
//   }
//
// });
//
// console.log(carnames);
  var ctx = document.getElementById("myDoughnutChart");
  var myChart = new Chart(ctx, {
  type: 'doughnut',
     data: {
       labels: [data[0].CarName,data[1].CarName,data[2].CarName,data[3].CarName,data[4].CarName],
       datasets: [
         {
           label: "Best Selling Cars",
           backgroundColor: [
               'rgba(255, 99, 132, 0.2)',
               'rgba(54, 162, 235, 0.2)',
               'rgba(255, 206, 86, 0.2)',
               'rgba(75, 192, 192, 0.2)',
               'rgba(153, 102, 255, 0.2)',
               'rgba(255, 159, 64, 0.2)'
           ],  borderColor: [
                 'rgba(255,99,132,1)',
                 'rgba(54, 162, 235, 1)',
                 'rgba(255, 206, 86, 1)',
                 'rgba(75, 192, 192, 1)',
                 'rgba(153, 102, 255, 1)',
                 'rgba(255, 159, 64, 1)'
             ],
              borderWidth: 1,
           data: [data[0].CarsBought,data[1].CarsBought,data[2].CarsBought,data[3].CarsBought,data[4].CarsBought]
         }
       ]
     },
     options: {
       title: {
         display: true,
         text: 'Most Bought Cars'
       }
     }
  });

}

// Most Buying Users
function getmostbuyingusers(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_sales.php",
    data: ({option :"5"}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        console.log(data[0]);
        getmostbuyingusersdoughnut(data);
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

function getmostbuyingusersdoughnut(data){
  var ctx = document.getElementById("myDoughnutBuyersChart");
  var myChart = new Chart(ctx, {
  type: 'doughnut',
     data: {
       labels: [data[0].FullName,data[1].FullName,data[2].FullName,'fsdafsad','fasfasd'],
       datasets: [
         {
           label: "Best Buyer (per month)",
           backgroundColor: [
               'rgba(255, 99, 132, 0.2)',
               'rgba(54, 162, 235, 0.2)',
               'rgba(255, 206, 86, 0.2)',
               'rgba(75, 192, 192, 0.2)',
               'rgba(153, 102, 255, 0.2)',
               'rgba(255, 159, 64, 0.2)'
           ],  borderColor: [
                 'rgba(255,99,132,1)',
                 'rgba(54, 162, 235, 1)',
                 'rgba(255, 206, 86, 1)',
                 'rgba(75, 192, 192, 1)',
                 'rgba(153, 102, 255, 1)',
                 'rgba(255, 159, 64, 1)'
             ],
              borderWidth: 1,
           data: [data[0].CarsBought,data[1].CarsBought,data[2].CarsBought,2,1]
         }
       ]
     },
     options: {
       title: {
         display: true,
         text: 'Most Buying Users'
       }
     }
  });
}


// General Statistics
function getgeneralstatistics(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"",
    data: ({option :""}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        getmostbuyingusersdoughnut(data);
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

function getgeneralstatisticsline(data){
  var ctx = document.getElementById("myGeneralChart");
  var myChart = new Chart(ctx, {
    type: 'line',
      data: {
        labels: ['January','February','March','April','May','June','July','August','September','October','November','December'],
        datasets: [{
            data: [86,114,106,106,107,111,133,221,783,2478,600,100],
            label: "Profit",
            borderColor: "#3e95cd",
            fill: false
          }, {
            data: [282,350,411,502,635,809,947,1402,3700,5267,600,100],
            label: "Users",
            borderColor: "#8e5ea2",
            fill: false
          }, {
            data: [168,170,178,190,203,276,408,547,675,734,600,100],
            label: "Cars",
            borderColor: "#3cba9f",
            fill: false
          }, {
            data: [40,20,10,16,24,38,74,167,508,784,600,100],
            label: "Buyers",
            borderColor: "#e8c3b9",
            fill: false
          }, {
            data: [6,3,2,2,7,26,82,172,312,433,600,100],
            label: "Reviews",
            borderColor: "#c45850",
            fill: false
          }
        ]
      },
      options: {
        title: {
          display: true,
          text: "Progress Of Website And It's Goal"
        }
      }
    });

}

// Most Updated Car

function getmostcarviewers(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"ws_cars.php",
    data: ({option :"11"}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        getmostviewersbar(data);
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

function getmostviewersbar(data){
  var ctx = document.getElementById("myMostViewerChart");
  var myChart = new Chart(ctx, {
    type: 'bar',
        data: {
          labels: [data[0].Year,data[1].Year,data[2].Year,data[3].Year],
          datasets: [
            {
              label: "Year Made",
              backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
              data: [data[0].Count,data[1].Count,data[2].Count,data[3].Count]
            }
          ]
        },
        options: {
          legend: { display: false },
          title: {
            display: true,
            text: 'Best Selling Modal Cars '
          }
        }
    });
}

// Number Of Visited Users Today
function getmostvisited(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"",
    data: ({option :""}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        $("#mostvisitedinfo").append(data[0]+" Is The Most User Visiting The Website");
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

// Money Made Today
function getmoneymadetoday(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"",
    data: ({option :""}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        $("#mostmoneymadetoday").append("We Made About "+data[0]+"$ Today");
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

// Our Current Status
function getourcurrentstatus(){
  $.ajax({
    type: 'GET',
    url: window.serverURL+"",
    data: ({option :""}),

    dataType: 'json',
    timeout: 5000,
    success: function(data, textStatus, xhr)
    {

      if(data==0)
        alert("Data couldn't be loaded!")
      else{
        data = JSON.parse(xhr.responseText);
        if(data[0]>=1000)
        $("#ourcurrentstatus").append("We Are Achieving Our Goal Today");
        else{
          $("#ourcurrentstatus").append("We Losing Our Goal Today");
        }
    }
  },
    error: function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

// Reservations For Graphs
function getReservationsForGraphs(){

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_sales.php",
        data: ({option :"1"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }


  // Sum Of Sold Cars
  function getSumOfSoldCars(){

        $.ajax({
          type: 'GET',
          url: window.serverURL+"ws_sales.php",
          data: ({option :"7"}),

          dataType: 'json',
          timeout: 5000,
          success: function(data, textStatus, xhr)
          {

            if(data==0)
              alert("Data couldn't be loaded!")
            else{
              data = JSON.parse(xhr.responseText);
              console.log(data);
              $("#mostmoneymadetoday").text(data[0].Price+"$ Till Now");
            }
          },
          error: function(xhr, status, errorThrown)
          {
            alert(status + errorThrown);
          }
        });  //

    }


// // To Set The DropDown Value As The Selected Value
//   $('.dropdown-menu a').on('click', function(){
// $('.dropdown-toggle').html($(this).html());
// });

});
