<?php
  // Start Session
  session_start();

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="..\Links\bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="chartjs\Chart.min.js"></script>
    <script src="..\Links\bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet"  type="text/css" href="..\css\animate.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <link href="index.css" type="text/css" rel="stylesheet"/>
  </head>
  <body>

<!-- Top NavBar -->
    <nav class="navbar navbar-light bg-light">
      <a class="navbar-brand">BINTUL</a>
      <form class="form-inline">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        <div class="btn-group marginleftnavbtn">
          <button type="button" class="btn backgroundtransparent" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="..\Images\koenigsegg.jpg" id="profileimage"/>
            <i class="fas fa-sort-down"></i>
          </button>
          <div class="dropdown-menu dropdown-menu-right">
            <button class="dropdown-item" type="button" id="viewprofile">View Profile</button>
            <button class="dropdown-item" type="button" id="logoutbutton">Logout</button>
          </div>
        </div>
      </form>
    </nav>

<!-- Side NavBar -->
  <div class="col-md-2 col-2" id="fixedsidenavbar">
    <div class="col-12"></div>
    <div class="col-12">
      <a href="#" id="viewusers"><i class="fas fa-users"></i> Users</a>
    </div>
    <hr>
    <div class="col-12">
      <a href="#" id="viewcars"><i class="fas fa-car-alt"></i> Cars</a>
    </div>
    <hr>
    <div class="col-12">
      <a href="#" id="viewsold"><i class="fas fa-book"></i> Sales</a>
    </div>
    <hr>
    <hr>
    <div class="col-12">
      <a href="#" id="viewbrands"><i class="fas fa-chart-pie"></i> Brands</a>
    </div>
    <hr>
    <div class="col-12">
      <a href="#" id="viewcategories"><i class="fas fa-chart-pie"></i> Categories</a>
    </div>
    <hr>
    <div class="col-12">
      <a href="#" id="viewstatistics"><i class="fas fa-chart-pie"></i> Statistics/ Dashboard</a>
    </div>
    <hr>
  

  </div>

<!-- Middle Div Information -->
  <div class="col-md-10 col-10 offset-md-2" id="mainmiddledivinfo">

<!-- Cars -->
    <table class="table table-hover middletable" id="cartable">
      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Brand</th>
          <th scope="col">Category</th>
          <th scope="col">Year</th>
          <th scope="col">Color</th>
          <th scope="col">#Seats</th>
          <th scope="col">Price</th>
          <!-- <th scope="col">Posted</th> -->
          <th scope="col">Description</th>
          <th scope="col">Active</th>
          <th scope="col">Modifitcation</th>
        </tr>
      </thead>
      <tbody id="cartableinside">

      </tbody>
    </table>

    <!-- Users -->
    <table class="table table-hover middletable" id="users">
      <thead>
        <tr>
          <th scope="col">First Name</th>
          <th scope="col">Last Name</th>
          <th scope="col">Phone</th>
          <th scope="col">Email</th>
          <th scope="col">Username</th>
          <th scope="col">Active</th>
          <th scope="col">Admin</th>
          <th scope="col">Modify</th>
        </tr>
      </thead>
      <tbody id="usersinside">
        <tr>
          <td>Mark</td>
          <td>Otto</td>
          <td>@mdo</td>
          <td>Mark</td>
          <td>Otto</td>
          <td>Mark</td>
          <td>Otto</td>
          <td class="modification">
            <a class="update" href="#"><i class="fas fa-wrench"></i></a>
            <a class="delete" href="#"> <i class="fas fa-trash-alt"></i></a>
          </td>
        </tr>
      </tbody>
    </table>

<!-- Reservations -->
<table class="table table-hover middletable" id="reservations">
  <thead>
    <tr>
      <th scope="col">Full Name</th>
      <!-- <th scope="col">First Name</th> -->
      <th scope="col">Car Name</th>
      <th scope="col">Description</th>
      <th scope="col">Year</th>
      <th scope="col">Color</th>
      <th scope="col">Price</th>
      <th scope="col">Date Bought</th>
    </tr>
  </thead>
  <tbody>
    <tr>

    </tr>

  </tbody>
</table>

<!-- Brands -->
<table class="table table-hover middletable" id="brands">
  <thead>
    <tr>
      <th scope="col">Brand Name</th>
      <th scope="col">Active</th>
      <th scope="col">Modify</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Mark</td>
      <td>Otto</td>
      <td class="modification">
        <a class="update" href="#"><i class="fas fa-wrench"></i></a>
        <a class="delete" href="#"> <i class="fas fa-trash-alt"></i></a>
      </td>
    </tr>

  </tbody>
</table>

<!-- Categories -->
<table class="table table-hover middletable" id="categories">
  <thead>
    <tr>
      <th scope="col">Category Name</th>
      <th scope="col">Active</th>
      <th scope="col">Modify</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Mark</td>
      <td>Otto</td>
      <td class="modification">
        <a class="update" href="#"><i class="fas fa-wrench"></i></a>
        <a class="delete" href="#"> <i class="fas fa-trash-alt"></i></a>
      </td>
    </tr>

  </tbody>
</table>

<!-- Graphs -->
<div class="col-md-12" id="dashboardstatistics">
<canvas id="myDoughnutChart"></canvas>
<canvas id="myDoughnutBuyersChart"></canvas>
<canvas id="myGeneralChart"></canvas>
<canvas id="myMostViewerChart"></canvas>
<div id="accordion">

  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Sum Of Sold Cars
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" id="mostmoneymadetoday">
      </div>
    </div>
  </div>

</div>
</div>

<!-- Almost Ends Here -->
  </div>

<div class="col-md-10 offset-md-2" id="paginationnav">
  <nav aria-label="Page navigation example">
    <ul class="pagination">
      <li class="page-item"><a class="page-link" href="#">Previous</a></li>
      <li class="page-item"><a class="page-link" href="#">1</a></li>
      <li class="page-item"><a class="page-link" href="#">2</a></li>
      <li class="page-item"><a class="page-link" href="#">3</a></li>
      <li class="page-item"><a class="page-link" href="#">Next</a></li>
    </ul>
  </nav>
</div>

<script src="index.js" type="text/javascript"></script>
<script src="..\js\Admin.js" type="text/javascript"></script>
<script type="text/javascript">

$("#logoutbutton").on("click",function(){
  logoutcurruser();
});

// Logout
function logoutcurruser(){

		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_users.php",
			  data: ({option :"9"}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data==0)
					  alert("Data couldn't be loaded!")
				  else{
				        window.location.href="../index.php";
				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}

  $("#viewprofile").on("click",function(){
    window.location="../viewprofile.php";

  });

  var adminexist='<?php echo isset($_SESSION['uadmin']);?>';
  if(adminexist.length==0){
    window.location="../index.php";
  }

</script>

  </body>
</html>
