<?php
// Start Session
session_start();
if(isset($_SESSION["uid"])==0){
  header("Location: http://localhost/finalproject/index.php");
};
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
<link rel="stylesheet" href="..\Links\bootstrap.min.css" >
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="..\Links\bootstrap.min.js" ></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="myreservation.css" type="text/css"/>
  </head>

  <body>

  <div class="col-md-1" id="sidebar">
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-angle-double-right itemicon"></i></a>
        <!-- <i class="fas fa-arrow-right"></i> -->
      </div>
      <div class="col-md-12" id="divprofileimage">
        <a href="..\viewprofile.php"><img src="car.jpg" id="profileimage"/></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-search itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="..\home.php"><i class="fas fa-home itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-bookmark itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="..\cars.php"><i class="fas fa-car-alt itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="..\carbrands.php"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:100%;height:100%;"></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="..\Reviews@ndComments\comment.php" id="messageicon"><i class="far fa-comments itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem" id="logoutbutton">
        <a href="..\index.php"><i class="fas fa-door-open itemicon"></i></a>
      </div>
    </div>

  <nav class="navbar navbar-expand-lg navbar-light bg-light d-block d-sm-none navbarsidebar">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent2">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
              <a href="home.php"><i class="fas fa-home itemicon"></i> <span class="navbarforsidebar">Home</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><i class="fas fa-bookmark itemicon"></i> <span class="navbarforsidebar">Bookmark</span></a>
          </li>
          <li class="nav-item active">
            <a href="cars.php"><i class="fas fa-car-alt itemicon"></i> <span class="navbarforsidebar">View Cars</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:40px;margin-top:15px;"> <span class="navbarforsidebar">Brands</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="freedommessageicon"><i class="far fa-comments itemicon"></i> <span class="navbarforsidebar">FreedomMessage</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="logoutbutton"><i class="fas fa-door-open itemicon"></i> <span class="navbarforsidebar">Logout</span></a>
          </li>
        </ul>
      </div>
    </nav>

  <div class="container offset-md-1" id="mycars">




  </div>

<!-- <script type="text/javascript" src="comment.js"></script> -->
<script type="text/javascript">

$(document).ready(function(){

  	window.serverURL = "http://localhost/finalproject/server_side/ws/";

  getReservations();

  function getReservations(){

        var userid= <?php echo $_SESSION["uid"]; ?>;

  		  $.ajax({
  			  type: 'GET',
  			  url: window.serverURL+"ws_sales.php",
  			  data: ({option :"4",userid:userid}),

  			  dataType: 'json',
  			  timeout: 5000,
  			  success: function(data, textStatus, xhr)
  			  {

  				  if(data<=0)
  					  alert("Data couldn't be loaded!")
  				  else{
  				  	data = JSON.parse(xhr.responseText);

  					populateMyReservations(data);
  				  }
  			  },
  			  error: function(xhr, status, errorThrown)
  			  {
  				  alert(status + errorThrown);
  			  }
  		  });  //

  	}

  function populateMyReservations(data){

    var item;

		if(data.length>0){

		   $.each(data, function(index, row) {

			  item= `
        <div class="card" style="width: 20rem;">
        <img class="card-img-top" src="car.jpg" alt="Card image cap">
        <div class="card-body">
				<a href="#" id="cardetails`+row.ID+`">
          <h5 class="card-title" id='carprice`+row.ID+`'>`+row.Price+` $</h5>
          <h6 class="card-title"><i class="fas fa-chair"></i><span id="numseat`+row.ID+`">`+row.Seats+`</span> &ensp; <i class="fas fa-car-side"></i><span id="availablecars`+row.ID+`"> Owned</span></h6>
          <p class="card-text" id="carcategory`+row.ID+`">`+row.Category+` <br/>
              <span id="`+row.ID+`">`+row.Brand+`</span>
          </p>
					</a>
          <h4 class="card-title" id="carname`+row.ID+`">`+row.CarName+`</h4>
        </div>
      </div>
        `;

		 	$("#mycars").append(item);

			});
		}

  }


  $("#logoutbutton").on("click",function(){
    logoutcurruser();
  });

  // Logout
  function logoutcurruser(){

  		  $.ajax({
  			  type: 'GET',
  			  url: window.serverURL+"ws_users.php",
  			  data: ({option :"9"}),

  			  dataType: 'json',
  			  timeout: 5000,
  			  success: function(data, textStatus, xhr)
  			  {

  				  if(data==0)
  					  alert("Data couldn't be loaded!")
  				  else{
  				        window.location.href="../index.php";
  				  }
  			  },
  			  error: function(xhr, status, errorThrown)
  			  {
  				  alert(status + errorThrown);
  			  }
  		  });  //

  	}


    $("#messageiconsmall").on("click",function(){
      window.location.href="Reviews@ndComments\\comment.php";
    });


});
</script>
  </body>

</html>
