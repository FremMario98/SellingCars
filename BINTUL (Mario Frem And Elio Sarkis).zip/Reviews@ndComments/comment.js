// $(document).ready(function(){
//
//   	window.serverURL = "http://localhost/finalproject/server_side/ws/";
//
//   getComments();
//
//   function getComments(){
//
//   		  $.ajax({
//   			  type: 'GET',
//   			  url: window.serverURL+"ws_freedomreviews.php",
//   			  data: ({option :"1"}),
//
//   			  dataType: 'json',
//   			  timeout: 5000,
//   			  success: function(data, textStatus, xhr)
//   			  {
//
//   				  if(data<=0)
//   					  alert("Data couldn't be loaded!")
//   				  else{
//   				  	data = JSON.parse(xhr.responseText);
//
//   					populateComments(data);
//   				  }
//   			  },
//   			  error: function(xhr, status, errorThrown)
//   			  {
//   				  alert(status + errorThrown);
//   			  }
//   		  });  //
//
//   	}
//
//   function populateComments(data){
//
//   		var item;
//
//   		if(data.length>0){
//
//   		   $.each(data, function(index, row) {
//
//   			  item= `
//           <div class="rounddivshape">
//               <div class="col-md-1 col-3 divroundimage">
//                   <img src="car.jpg" class="roundimage"/>
//               </div>
//               <div class="col-md-10 col-8">
//                   <h4>`+row.UserName+`</h4>
//                   <p>`+row.Comment+`<p>
//               </div>
//           </div>
//           `;
//
//   		 	$("#reviewscontainer").append(item);
//
//   			});
//
//         item2= `
//         <div class="col-md-12 col-12 rounddivshape" style="display:flex;">
//             <div class="col-md-1 col-3 divroundimage" style="display:contents;">
//                 <img src="car.jpg" class="roundimage"/>
//             </div>
//             <div class="col-md-10 col-8" style="text-align:left;">
//               <textarea id="commentreview" name="" id="" style="width:100%;height:100%;border-radius:15px;resize:none;" placeholder="Add A Comment ..."></textarea>
//             </div>
//             <div class="col-md-1">
//               <a href="#" id="postreview"><i class="far fa-clipboard" style="font-size:5em;"></i></a>
//             </div>
//
//           </div>
//         `;
//         $("#reviewscontainer").append(item2);
//
//   		}
//   	}

//   $("#postreview").on("click",function(){
//       postComments();
//   });
//
// // Post Comment
//   function postComments(){
//
//         var commentreview=$("#commentreview").val();
//         var userid= <?php echo 	$_SESSION["uUserName"] ?>;
//
//         $.ajax({
//           type: 'GET',
//           url: window.serverURL+"ws_freedomreviews.php",
//           data: ({option :"2"}),
//
//           dataType: 'json',
//           timeout: 5000,
//           success: function(data, textStatus, xhr)
//           {
//
//             if(data<=0)
//               alert("Data couldn't be loaded!")
//             else{
//               data = JSON.parse(xhr.responseText);
//
//             getComments();
//             }
//           },
//           error: function(xhr, status, errorThrown)
//           {
//             alert(status + errorThrown);
//           }
//         });  //
//
//     }

// });
