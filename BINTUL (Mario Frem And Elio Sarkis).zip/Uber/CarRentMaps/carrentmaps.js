

$(document).ready(function(){


    var locations = [
        [1,'Sahel Alma',33.984389, 35.646662],
        [2,'Fouad Chehab Stadium',33.986453, 35.639205],
        [3,'Caliprix',34.000678, 35.647855],
        [4,'AUT Halat',34.096620, 35.653956],
      ];

    //   const location=get_allcarscoordinates();

      var map= new google.maps.Map(document.getElementById('map'),{
          zoom:10.5,
          center: new google.maps.LatLng(33.895012, 35.653620),
          mapTypeId: google.maps.MapTypeId.ROADMAP
      });

      var infowindow= new google.maps.InfoWindow;

    var marker,i;

    for(i=0;i< locations.length;i++){
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][2],locations[i][3]),
            map:map
        });

        google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
            return function() {
              infowindow.setContent(locations[i][1]);
              infowindow.open(map, marker);
            }
          })(marker, i));

        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
              window.location.href="http://localhost/finalproject/viewcardetails.php?option=5&id="+locations[i][0];
            }
          })(marker, i));

    }


    function get_allcarscoordinates(){
        $.ajax({
            type: 'GET',
            url: window.serverURL+"ws_cars.php",
            data: ({option :""}),

            dataType: 'json',
            timeout: 5000,
            success: function(data, textStatus, xhr)
            {

                var location = [
                    [1,'Sahel Alma',33.984389, 35.646662],
                    [2,'Fouad Chehab Stadium',33.986453, 35.639205],
                    [3,'Caliprix',34.000678, 35.647855],
                    [4,'AUT Halat',34.096620, 35.653956],
                  ];
            
                
                  var map= new google.maps.Map(document.getElementById('map'),{
                      zoom:10.5,
                      center: new google.maps.LatLng(33.895012, 35.653620),
                      mapTypeId: google.maps.MapTypeId.ROADMAP
                  });
            
                  var infowindow= new google.maps.InfoWindow;
            
                var marker,i;
            
                for(i=0;i< location.length;i++){
                    marker = new google.maps.Marker({
                        position: new google.maps.LatLng(location[i][2],location[i][3]),
                        map:map
                    });
            
                    google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
                        return function() {
                          infowindow.setContent(location[i][1]);
                          infowindow.open(map, marker);
                        }
                      })(marker, i));
            
                    google.maps.event.addListener(marker, 'click', (function(marker, i) {
                        return function() {
                          window.location.href="http://localhost/finalproject/viewcardetails.php?option=5&id="+locations[i][0];
                        }
                      })(marker, i));
            
                }


            },
            error: function(xhr, status, errorThrown)
            {
                alert(status + errorThrown);
            }
        });  //
    }


});