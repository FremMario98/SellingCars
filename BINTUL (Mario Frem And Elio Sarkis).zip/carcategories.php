<?php
  // Start Session
  session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="Links\bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="Links\bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link href="css\displayrentcars.css" rel="stylesheet" type="text/css"/>
  </head>
  <body>

    <div class="col-md-1" id="sidebar">
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-angle-double-right itemicon"></i></a>
        <!-- <i class="fas fa-arrow-right"></i> -->
      </div>
      <div class="col-md-12" id="divprofileimage">
        <a href="home.php"><img src="Images\koenigsegg.jpg" id="profileimage"/></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-search itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="home.php"><i class="fas fa-home itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="Reservation\myreservation.php"><i class="fas fa-bookmark itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="cars.php"><i class="fas fa-car-alt itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="carbrands.php"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:100%;height:100%;"></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="Reviews@ndComments/comment.php" id="messageicon"><i class="far fa-comments itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem" id="logoutbutton">
        <a href="index.php"><i class="fas fa-door-open itemicon"></i></a>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light d-block d-sm-none navbarsidebar">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent2">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
              <a href="home.php"><i class="fas fa-home itemicon"></i> <span class="navbarforsidebar">Home</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><i class="fas fa-bookmark itemicon"></i> <span class="navbarforsidebar">Bookmark</span></a>
          </li>
          <li class="nav-item active">
            <a href="cars.php"><i class="fas fa-car-alt itemicon"></i> <span class="navbarforsidebar">View Cars</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:40px;margin-top:15px;"> <span class="navbarforsidebar">Brands</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="freedommessageicon"><i class="far fa-comments itemicon"></i> <span class="navbarforsidebar">FreedomMessage</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="logoutbutton"><i class="fas fa-door-open itemicon"></i> <span class="navbarforsidebar">Logout</span></a>
          </li>
        </ul>
      </div>
    </nav>

  <div class="col-md-10 offset-md-2 col-10 offset-1" id="containerofcars">

    </div>

<!-- All jQuery And Ajax -->
    <script
      src="https://code.jquery.com/jquery-3.3.1.min.js"
      integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <script type="text/javascript" src="js\cars.js"></script>

<script type="text/javascript">

window.serverURL = "http://localhost/finalproject/server_side/ws/";

$("#messageicon").on("click",function(){
	if($("#messagedialog").css("right")=="-1300px")
	{
    $("#messagedialog").css("right","0%");
    getComments();
}
	else{
		$("#messagedialog").css("right","-1300px");
      $("#messagedialog").empty();
	}

});

getComments();

function getComments(){

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_freedomreviews.php",
        data: ({option :"1"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data<=0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);

          populateComments(data);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }

function populateComments(data){

    var item;

    if(data.length>0){

       $.each(data, function(index, row) {

        item= `
        <div class="col-md-12 mainmessagedialogbox">
          <div class="col-md-12">
            <img src="Images\\koenigsegg.jpg" class="imageofmessagedialog"/>
          <h3>`+row.UserName+`</h3>
          <p>`+row.Comment+`</p>
          </div>
        </div>
        `;

      // $("#reviewscontainer").prepend(item);
      $("#messagedialog").prepend(item);

      });

    }
  }

  $("#logoutbutton").on("click",function(){
    logoutcurruser();
  });

  // Logout
  function logoutcurruser(){

  		  $.ajax({
  			  type: 'GET',
  			  url: window.serverURL+"ws_users.php",
  			  data: ({option :"9"}),

  			  dataType: 'json',
  			  timeout: 5000,
  			  success: function(data, textStatus, xhr)
  			  {

  				  if(data==0)
  					  alert("Data couldn't be loaded!")
  				  else{
  				        window.location.href="index.php";
  				  }
  			  },
  			  error: function(xhr, status, errorThrown)
  			  {
  				  alert(status + errorThrown);
  			  }
  		  });  //

  	}


    $("#freedommessageicon").on("click",function(){
      window.location.href="Reviews@ndComments\\comment.php";
    });

</script>
  </body>
</html>
