<?php
  // Start Session
  session_start();

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="Links\bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="Links\bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css\slideimagehover.css">
    <link rel="stylesheet"  type="text/css" href="css\animate.css" >
<!-- Not All The jQuery Are Downloaded So We Put jQuery CDN -->
    <script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
  <script type="text/javascript" src="js\Chart.min.js"></script>
  </head>
  <body>
    <ul class="homepage d-none d-sm-block d-md-block">
      <li class="maindirectorypages" id="insidehomepage">
        <!-- NavBar Inside li -->
        <div id="navfixed">
              <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navbarfixed">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                          <a class="nav-link animated slideInLeft" href="#innerpage1">Home <i class="fas fa-home"></i><span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#innerpage2">Our Story <i class="fas fa-book"></i></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#innerpage3">Experience <i class="fas fa-brain"></i></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#innerpage4">Owners <i class="fas fa-crown"></i></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#innerpage5">Location <i class="fas fa-map-marked-alt"></i></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#innerpage6">Contact Us <i class="far fa-address-book"></i></a>
                        </li>
                        <li class="nav-item" style="position:absolute;right:0px;"><ul style="list-style-type: none;display:flex;">
                        <li class="nav-item">
                          <a class="nav-link" href="viewprofile.php"><img src="Images\koenigsegg.jpg" style="border-radius:20px;width:35px;height:35px;"/></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="index.php" id="logoutbutton"><i class="fas fa-door-open"></i> Logout</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="Admin\index.php" id="gotobackend">Back-End <i class="fas fa-sign-out-alt"></i></a>
                        </li></ul>
                      </li>
                      </ul>
                    </div>
                  </nav>
                </div>


                  <div id="innerpage1"></div>
                  <div id="innerpage2">
                    <div class="conatiner" id="centerinnerpage2">
                        <h1 class="animated SlideInUp"> About Us</h1>
                        <div class="col-md-12 col-12" id="aboutuscards">
                          <div class="card col" style="width: 18rem;">
                              <img class="card-img-top" src="Images\trophy.jpg" alt="Card image cap">
                              <div class="card-body">
                                <h5 class="card-title">We Are Number One With What We Do</h5>
                              </div>
                            </div>
                            <div class="card col" style="width: 18rem;">
                                <img class="card-img-top" src="Images\workhard.jpg" alt="Card image cap">
                                <div class="card-body">
                                  <h5 class="card-title">We Work Hard, Get All Tasks Done, Even Before Time</h5>
                                </div>
                              </div>
                              <div class="card col" style="width: 18rem;">
                                  <img class="card-img-top" src="Images\Aimachievment.png" alt="Card image cap">
                                  <div class="card-body">
                                    <h5 class="card-title">You Dream And We Achieve</h5>
                                  </div>
                                </div>

                              </div>
                    </div>
                  </div>
                  <div class="container animate slideInLeft" id="innerpage3">
                    <div class="col-md-12" id="innerpage3element" style="display:flex;">
                      <div class="col-md-12" style="margin-bottom:15px;"><canvas id="myProfitChart"></canvas></div><br/>
                      <div class="col-md-12" style="margin-bottom:15px;"><canvas id="myUsersChart"></canvas></div><br/>
                      <div class="col-md-5"><img src="http://blog.orangescrum.com/wp-content/uploads/2018/05/7-things-project-managers-should-do-everyday.png" style="width:100%;height:300px;"/></div>
                      <div class="col-md-7" style="margin-bottom:25px;"><canvas id="mySatisfactionChart"></canvas></div>
                    </div>
                  </div>
                  <div id="innerpage4">
                    <div class="card" style="width: 30%;height:90%;overflow:hidden;margin-right:40px;">
                        <img class="card-img-top" src="https://musicimage.xboxlive.com/catalog/video.movie.8D6KGWXN2HJR/image?locale=en-us&mode=crop&purposes=BoxArt&q=90&h=300&w=200&format=jpg" alt="Card image cap">
                        <div class="card-body">
                          <h5 class="card-title">
                            DeadPool Movie
                          </h5>
                          <p>Web Developer</p>
                        </div>
                      </div>
                      <div class="card" style="width: 30%;height:90%;overflow:hidden;margin-left:40px;">
                          <img class="card-img-top" src="https://musicimage.xboxlive.com/catalog/video.movie.8D6KGWXN2HJR/image?locale=en-us&mode=crop&purposes=BoxArt&q=90&h=300&w=200&format=jpg" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title">
                              DeadPool Movie
                            </h5>
                            <p>Web Developer</p>
                          </div>
                        </div>
                  </div>
                  <div class="col-md-12" id="innerpage5">
                      <div class="col row align-self-center align-items-center">
                         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3303.943074682127!2d35.65163151470056!3d34.0965987228398!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151f44a091e10f33%3A0x69204d5b19911b0e!2sAmerican+University+of+Technology%2C+Halat+Campus!5e0!3m2!1sen!2slb!4v1543833855319" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                      </div>
                  </div>
                  <div class="col-md-12" id="innerpage6">

                    <div class="col-md-6" id="contactinputfield">
                      <div class="col-md-12">
                        <label for="contactname">Name</label>
                        <input type="text" class="col-md-12" id="contactname"/>
                      </div>
                      <div class="col-md-12">
                        <label for="contactemail">Email</label>
                        <input type="text" class="col-md-12" id="contactemail"/>
                      </div>
                      <div class="col-md-12">
                        <label for="contactmessage">Message</label>
                        <textarea class="col-md-12" cols="30" rows="3" id="contactmessage"></textarea>
                      </div>
                      <div class="col-md-12">
                        <button><a href="#"> Send Message </a></button>
                      </div>
                    </div>

                    <div class="col-md-6 aboutusinfo">
                      <div class="col-md-12 aboutdisplay">
                        <div class="col-md-5">
                          <h3>Address</h3>
                        </div>
                        <div class="col-md-6">
                          <p>
                            Ghazir Street Near SomeWhere<br/>
                            #Floor, #St Building</p>
                        </div>
                      </div>
                      <div class="col-md-12 aboutdisplay">
                        <div class="col-md-5">
                          <h3>Phone</h3>
                        </div>
                        <div class="col-md-6">
                          <p>Our Phone Number 09432342<p>
                        </div>
                      </div>
                      <div class="col-md-12 aboutdisplay">
                        <div class="col-md-5">
                          <h3>Email</h3>
                        </div>
                        <div class="col-md-6">
                          <p>Emailofteam@here.com</p>
                        </div>
                      </div>
                      <div class="col-md-12" id="socialmedia">
                        <div class="col-md-5">
                          <h3>Social</h3>
                        </div>
                        <div class="col-md-6">
                          <i class="fab fa-twitter socialmediaround"></i>
                          <i class="fab fa-facebook-f socialmediaround facebookicon"></i>
                          <i class="fab fa-instagram socialmediaround"></i>
                          <i class="fab fa-github socialmediaround"></i>
                        </div>
                      </div>
                    </div>

                  </div>
                  <div id="innerpage7">
                    <div class="container" id="copyrightendpage">
                      <div class="col-md-3"><i class="far fa-copyright"></i> RINRIL</div>
                      <div class="col-md-3"><i class="fas fa-headset"></i> 24/7 Online Support</div>
                      <div class="col-md-3"><i class="fas fa-shield-alt"></i> Total Privacy</div>
                      <div class="col-md-3"><i class="fas fa-map-signs"></i> In Any Direction,We're There</div>
                    </div>
                  </div>
          <a href="#">
        <div class="content" id="homecontent">
          <h1>About Us <i class="fas fa-medal"></i> <i class="fas fa-people-carry"></i></h1>
          <p></p>
        </div>
        </a>
      </li>

      <li class="maindirectorypages">
          <a href="cars.php">
        <div class="content">
          <h1>Search<i class="fas fa-user-astronaut"></i></h1>
          <p></p>
        </div>
        </a>
      </li>

      <li class="maindirectorypages">
          <a href="carbrands.php">
        <div class="content">
          <h1>Brands <i class="fas fa-space-shuttle"></i></h1>
          <p></p>
        </div>
        </a>
      </li>

      <li class="maindirectorypages">
          <a href="Reservation\myreservation.php">
        <div class="content">
        <h1>My Cars <i class="far fa-clipboard"></i></h1>
        <p></p>
      </div>
      </a>
    </li>

      <li class="maindirectorypages">
        <a href="Reviews@ndComments\comment.php">
        <div class="content">
          <h1>Reviews <i class="far fa-comments"></i></h1>
          <p></p>
        </div>
        </a>
      </li>

    </ul>

<!-- Incase Of Small -->

<div class="container-fluid col-12 d-block d-sm-none " style="margin:0px;padding:0px;">
<!-- NAVBAR -->
      <nav class="navbar fixednavbarsmall navbar-expand-lg navbar-light transparent navbar-inverse">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link animated slideInLeft" href="#categories1"><i class="fas fa-user-astronaut"></i> Buy <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link animated slideInLeft" href="#brands1"><i class="fas fa-space-shuttle"></i> Brands</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link animated slideInLeft" href="#reservations1"><i class="far fa-clipboard"></i> Reservations</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link animated slideInLeft" href="#reviews1"><i class="fas fa-crown"></i> Reviews</a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link animated slideInLeft" href="#aboutus1"><i class="fas fa-medal"></i> <i class="fas fa-people-carry"></i> About Us</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="viewprofile.php" style="color:rgba(0,0,0,.9);"><img src="Images\koenigsegg.jpg" style="border-radius:20px;width:35px;height:35px;"/> Profile</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php" style="color:rgba(0,0,0,.9);"><i class="fas fa-door-open"></i> Logout</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#" id="gotobackend">Back-End <i class="fas fa-sign-out-alt"></i></a>
                </li>

              </ul>
            </div>
          </nav>



<!-- PAGE  -->
  <div class="col-12 smallpage" id="categories1">
      <a href="cars.php">
    <div class="content">
      <h1>Search For Cars Dream Car <i class="fas fa-user-astronaut"></i></h1>
      <p></p>
    </div>
    </a>
  </div>

  <div class="col-12 smallpage" id="brands1">
      <a href="carbrands.php">
    <div class="content">
      <h1>Search For Cars By Brands <i class="fas fa-space-shuttle"></i></h1>
      <p></p>
    </div>
    </a>
  </div>

  <div class="col-12 smallpage" id="reservations1">
      <a href="Reservation\myreservation.php">
    <div class="content">
        <h1>My Reservations <i class="far fa-clipboard"></i></h1>
      <p></p>
    </div>
    </a>
  </div>

  <div class="col-12 smallpage" id="reviews1">
      <a href="Reviews@ndComments\comment.php">
    <div class="content">
      <h1>Reviews <i class="far fa-comments"></i></h1>
      <p></p>
    </div>
    </a>
  </div>

  <div class="col-12 smallpageabout" id="aboutus1">
      <a href="#">
    <div class="content">
      <h1>About Us <i class="fas fa-medal"></i> <i class="fas fa-people-carry"></i></h1>
      <p></p>
    </div>
    </a>
    <div id="innerpage1"></div>
    <div id="innerpage2" style="min-height:250vh;background-color:white;">
      <div class="conatiner" id="centerinnerpage2" style="text-align:-webkit-center;">
                    <h1> About Us</h1>
        <div class="card col-8" style="width: 18rem;">
            <img class="card-img-top" src="Images\trophy.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title animated fadeInLeft">We Are Number One With What We Do</h5>
            </div>
          </div>
          <div class="card col-8" style="width: 18rem;">
              <img class="card-img-top" src="Images\workhard.jpg" alt="Card image cap">
              <div class="card-body">
                <h5 class="card-title animated jackInTheBox">We Work Hard, Get All Tasks Done, Even Before Time</h5>
              </div>
            </div>
            <div class="card col-8" style="width: 18rem;">
                <img class="card-img-top" src="Images\Aimachievment.png" alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title animated fadeInRight">You Dream And We Achieve</h5>
                </div>
              </div>
      </div>
    </div>
    <div class="container animate slideInLeft" id="innerpage3">
      <div class="col-md-12 col-12 chart-container" style="position: relative; height:40vh; width:80vw" id="innerpage3element">
        <div class="col-md-6 col-12"><canvas id="myProfitChart"></canvas></div>
        <div class="col-md-6 col-12"><canvas id="myUsersChart"></canvas></div><br/>
        <div class="col-md-8 col-12"><canvas id="mySatisfactionChart"></canvas></div>
      </div>
    </div>
    <div id="innerpage4 innerpage4small" class="col-12" style="text-align: -webkit-center;">
      <div class="card col-10 offset-1" style="overflow:hidden;">
          <img class="card-img-top" src="https://musicimage.xboxlive.com/catalog/video.movie.8D6KGWXN2HJR/image?locale=en-us&mode=crop&purposes=BoxArt&q=90&h=300&w=200&format=jpg" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">
              DeadPool Movie
            </h5>
            <p>Web Developer</p>
          </div>
        </div>
        <div class="card col-10 offset-1" style="overflow:hidden;">
            <img class="card-img-top" src="https://musicimage.xboxlive.com/catalog/video.movie.8D6KGWXN2HJR/image?locale=en-us&mode=crop&purposes=BoxArt&q=90&h=300&w=200&format=jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">
                DeadPool Movie
              </h5>
              <p>Web Developer</p>
            </div>
          </div>
    </div>
    <div class="col-11 offset-1" id="innerpage5">
        <div class="col row align-self-center align-items-center">
           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3303.943074682127!2d35.65163151470056!3d34.0965987228398!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151f44a091e10f33%3A0x69204d5b19911b0e!2sAmerican+University+of+Technology%2C+Halat+Campus!5e0!3m2!1sen!2slb!4v1543833855319" width="400px" height="450px" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
    <div class="col-12" id="innerpage6small">

      <div class="col-12" id="contactinputfield">
        <div class="col-12 aligncentersmall">
          <label for="contactname">&emsp;Name</label>
          <input type="text" class="col-md-12" id="contactname"/>
        </div>
        <div class="col-12 aligncentersmall">
          <label for="contactemail">&emsp;Email</label>
          <input type="text" class="col-12" id="contactemail"/>
        </div>
        <div class="col-12 aligncentersmall">
          <label for="contactmessage">&emsp;Message</label>
          <textarea class="col-12" cols="30" rows="3" id="contactmessage"></textarea>
        </div>
        <div class="col-12 aligncentersmall" id="sendmessagesmall">
          <button><a href="#"> Send Message </a></button>
        </div>
      </div>

      <div class="col-12 ">
        <div class="row col-12 aboutdisplay">
          <div class="col-12">
            <h3>Address</h3>
          </div>
          <div class="col-12">
            <p>
              Ghazir Street Near SomeWhere<br/>
              #Floor, #St Building</p>
          </div>
        </div>
        <div class="row col-12 aboutdisplay">
          <div class="col-12">
            <h3>Phone</h3>
          </div>
          <div class="col-12">
            <p>Our Phone Number 09432342<p>
          </div>
        </div>
        <div class="row col-12 aboutdisplay">
          <div class="col-12">
            <h3>Email</h3>
          </div>
          <div class="col-12">
            <p>Emailofteam@here.com</p>
          </div>
        </div>
        <div class="row col-12" id="socialmedia">
          <div class="col-12">
            <h3>Social</h3>
          </div>
          <div class="col-12">
            <i class="fab fa-twitter socialmediaround"></i>
            <i class="fab fa-facebook-f socialmediaround facebookicon"></i>
            <i class="fab fa-instagram socialmediaround"></i>
            <i class="fab fa-github socialmediaround"></i>
          </div>
        </div>
      </div>

    </div>

  </div>
  <div id="innerpage7 col-12">
    <div class="container-fluid" id="copyrightendpage">
      <div class="col-3"><i class="far fa-copyright"></i> BINTUL</div>
      <div class="col-3"><i class="fas fa-headset"></i> 24/7 Online Support</div>
      <div class="col-3"><i class="fas fa-shield-alt"></i> Total Privacy</div>
      <div class="col-3"><i class="fas fa-map-signs"></i> In Any Direction,We're There</div>
    </div>
  </div>

</div>

<script src="js\homepage.js"></script>
<script type="text/javascript">
var admin='<?php echo isset($_SESSION["uadmin"]); ?>';
  if(admin.length == 0){
    console.log("hi");
    $("#gotobackend").css("display","none");
  }
  else if(admin.length >= 1){
    var admin2='<?php echo $_SESSION["uadmin"]; ?>';
    if(admin2==0){
      $("#gotobackend").css("display","none");
    }
    }

    $("#logoutbutton").on("click",function(){
      logoutcurruser();
    });

    // Logout
    function logoutcurruser(){

    		  $.ajax({
    			  type: 'GET',
    			  url: window.serverURL+"ws_users.php",
    			  data: ({option :"9"}),

    			  dataType: 'json',
    			  timeout: 5000,
    			  success: function(data, textStatus, xhr)
    			  {

    				  if(data==0)
    					  alert("Data couldn't be loaded!")
    				  else{
    				        window.location.href="index.php";
    				  }
    			  },
    			  error: function(xhr, status, errorThrown)
    			  {
    				  alert(status + errorThrown);
    			  }
    		  });  //

    	}

</script>
  </body>
</html>
