<?php
  // Start Session

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
<link rel="stylesheet" href="Links\bootstrap.min.css" >
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="Links\bootstrap.min.js" ></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/index.css" type="text/css"/>
  </head>

  <body>
<div class="container">

<div class="row formlogin justify-content-center align-items-center">

  <div class="col-md-5 mainform" id="toggletoregister" style="background-color:transparent;">
    <div class="row justify-content-center marginall">
      <div class="col-md-8">
        <img src="Images\carlogoimage.jpg" id="logocarimage"/>
      </div>
    </div>
    <div class="row justify-content-center marginall">
      <div class="col-md-11 col-11">
        <label for="email" style="color:white;">Username/Email</label>
        <input type="text" id="email" class="col-md-12 form-control op1" placeholder="Username/Email">
      </div>
    </div>
    <div class="row justify-content-center marginall" id="appendhereiferror">
      <div class="col-md-11 col-11">
        <label for="password" style="color:white;">Password</label>
          <input type="password" id="password" class="col-md-12 form-control op1" placeholder="Password">
      </div>
    </div>
    <div class="col-md-11">
      <div class="row justify-content-center">
        <div class="col-10 col-md-5 offset-md-1">
          <button type="button" id="loginbutton" class="btn btn-primary btn-sm">Login</button>
        </div>
        <div class="col-10 col-md-5">
          <button class="button btn btn-primary btn-sm" id="registerbutton"><span>Register</span></button>
        </div>
      </div>
  </div>

  </div>

  <!-- BackFace Visibility -->

  </div>

    </div>


<script src="js\index.js"></script>
<script type="text/javascript">

// Login To Username(Or Email) And Password
$("#loginbutton").on("click",function(){
    verifyUser();
});
// Verify User And Password
function verifyUser(){

    let usern=$("#email").val();
    let pass=$("#password").val();

       $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_users.php",
        data: ({option :"1",credential:usern,password:pass}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {
          if(data==0)
            {
              $("#email").css("border","1px solid red");
              $("#password").css("border","1px solid red");
              if(!$("#appendhereiferror div").hasClass("errorverifyup")){
              $("#appendhereiferror").append("<div class='col-10 errorverifyup'>Invalid Username Or Password</div>");
            }
            }
          else{
            data = JSON.parse(xhr.responseText);
            window.location.href="home.php";
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }
</script>
  </body>
</html>
