
function populateUsersTable(data){

		//data = data.users;
		var item;

		$("#cartable").empty();

		if(data.length>0){

		   $.each(data, function(index, row) {

			  item=  "<tr>";
			  item+= "<td>"+row.u_fname+"</td>";
  			item+= "<td>"+row.u_lname+"</td>";
  			item+= "<td>"+row.u_phone+"</td>";
        item+= "<td>"+row.u_email+"</td>";
        item+= "<td>"+row.u_username+"</td>";
        item+= "<td>"+row.u_active+"</td>";
        item+= "<td>"+row.u_admin+"</td>";
			  item+= "<td class='modification'><a class='update' href='#'><i class='fas fa-wrench'></i></a> <a class='delete' href='#'> <i class='fas fa-trash-alt'></i></a></td>";
			  item+= "</tr>";

		 	$("#cartable").append(item);

			});
		}
	}
