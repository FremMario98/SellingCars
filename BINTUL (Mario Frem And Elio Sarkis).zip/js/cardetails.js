//
// $( document ).ready(function() {
//
// window.serverURL = "http://localhost/finalproject/server_side/ws/";
//
//     getCarInfo();
//
// // Function Get Car Details
// function getCarInfo(){
//
//       // var id=$_SESSION["currencarid"];
//       // var carid=parseInt(localStorage.getItem("carid"));
//       var carid= JSON.parse(localStorage.getItem('carid'));
//
// 		  $.ajax({
// 			  type: 'GET',
// 			  url: window.serverURL+"ws_cars.php",
// 			  data: ({option :"9",id:carid}),
//
// 			  dataType: 'json',
// 			  timeout: 5000,
// 			  success: function(data, textStatus, xhr)
// 			  {
//
// 				  if(data==0)
// 					  alert("Data couldn't be loaded!")
// 				  else{
// 				  	data = JSON.parse(xhr.responseText);
//
//             var carname=$("#carnameinfo");
//             var carbrand=$("#carbrandinfo");
//             var cartype=$("#cartypeinfo");
//             var carnumseat=$("#carnumseatsinfo");
//             var cardescription=$("#cardescriptioninfo");
//             var carprice=$("#carpricedescription");
//             var caryear=$("#caryearinfo");
//             var carcolor=$("#carcolorinfo");
//
//             carname.text(data[0].Name);
//             carbrand.text(data[0].Brand);
//             cartype.text(data[0].Category);
//             cardescription.text(data[0].Description);
//             caryear.text(data[0].Year);
//             carcolor.text(data[0].Color);
//             carnumseat.text("Maximum "+data[0].NumberofSeats +" Passengers Relaxed");
//             carprice.text(data[0].Price);
//
//             if(data[0].Status==0){
//               $("#buycurrentcar").prop('disabled', true);
//             }
//             else{
//               $("#buycurrentcar").prop('disabled', false);
//             }
//
// 				  }
// 			  },
// 			  error: function(xhr, status, errorThrown)
// 			  {
// 				  alert(status + errorThrown);
// 			  }
// 		  });  //
//
// 	}
//
//
//   $("#messageicon").on("click",function(){
//     if($("#messagedialog").css("right")=="-1300px")
//   	{$("#messagedialog").css("right","0%");}
//     else{
//       $("#messagedialog").css("right","-1300px");
//     }
//
//   });
//
//
// });
