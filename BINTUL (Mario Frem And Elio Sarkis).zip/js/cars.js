$(document).ready(function(){
	window.serverURL = "http://localhost/finalproject/server_side/ws/";
	// Cars Php File Open
	if (location.href == "http://localhost/finalproject/cars.php") {
					getCars();
					getSearchCategories();
					getSearchBrands();
					getSearchSeats();
					getSearchYears();
					getSearchColors();
}
//  Car Categories Php File Open
	else if(location.href == "http://localhost/finalproject/carcategories.php"){
					getCategories();
}
//  Car Brands Php File Open
	else if(location.href == "http://localhost/finalproject/carbrands.php"){
					getBrands();
}


// Get All Cars
function getCars(){

		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_cars.php",
			  data: ({option :"1"}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data<=0)
					  alert("Data couldn't be loaded!")
				  else{
				  	data = JSON.parse(xhr.responseText);

					populateCarsTable(data);
				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}

function populateCarsTable(data){

		var item;

		if(data.length>0){

		   $.each(data, function(index, row) {

			  item= `
        <div class="card" style="width: 20rem;">
        <img class="card-img-top" src="Images\\koenigsegg.jpg" alt="Card image cap">
        <div class="card-body">
				<a href="#" id="cardetails`+row.ID+`">
          <h5 class="card-title" id='carprice`+row.ID+`'>`+row.Price+` $</h5>
          <h6 class="card-title"><i class="fas fa-chair"></i><span id="numseat`+row.ID+`">`+row.NumberofSeats+`</span> &ensp; <i class="fas fa-car-side"></i><span id="availablecars`+row.ID+`">`+row.Status+`</span></h6>
          <p class="card-text" id="carcategory`+row.ID+`">`+row.Category+` <br/>
              <span id="`+row.ID+`">`+row.Brand+`</span>
          </p>
					</a>
          <h4 class="card-title" id="carname`+row.ID+`">`+row.Name+`</h4>
        </div>
      </div>
        `;

		 	$("#containerofcars").append(item);

			});
		}
	}

// Get All Categories For Categories Php File
function getCategories(){

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_categories.php",
        data: ({option :"1"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);

          populateCategoriesTable(data);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }

function populateCategoriesTable(data){

    //data = data.users;
    var item;

    if(data.length>0){

       $.each(data, function(index, row) {

        item=`
            <div class="col-lg-3 col-md-5 col-sm-6 col-10 squarecategories" id="category`+row.ID+`">
                <img src="Images\\carbrands.jpg" class="imagehover"/>
                <a href="#"id="`+row.ID+`"><span class="wordbreak">`+row.Category+`</span></a>
            </div>
        `;

      $("#containerofcars").append(item);

      });
    }
  }

// Get All Brands For Brands Php File
function getBrands(){

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_brands.php",
        data: ({option :"1"}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);

          populateBrandsTable(data);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }

function populateBrandsTable(data){

    //data = data.users;
    var item;

    if(data.length>0){

       $.each(data, function(index, row) {

        item=`
            <div class="col-lg-3 col-md-5 col-sm-6 col-10 squarecategories" id="brands`+row.ID+`">
                <img src="Images\\carbrands.jpg" class="imagehover"/>
                <a href="#"id="`+row.ID+`"><span class="wordbreak">`+row.Name+`</span></a>
            </div>
        `;

      $("#containerofcars").append(item);

      });
    }
  }

// For Search Get Categories
function getSearchCategories(){

			$.ajax({
				type: 'GET',
				url: window.serverURL+"ws_categories.php",
				data: ({option :"1"}),

				dataType: 'json',
				timeout: 5000,
				success: function(data, textStatus, xhr)
				{

					if(data==0)
						alert("Data couldn't be loaded!")
					else{
						data = JSON.parse(xhr.responseText);

					populateSearchCategoriesTable(data);
					}
				},
				error: function(xhr, status, errorThrown)
				{
					alert(status + errorThrown);
				}
			});  //

	}

function populateSearchCategoriesTable(data){

		//data = data.users;
		var item;

		if(data.length>0){

			 $.each(data, function(index, row) {

				 item="<option value='"+row.ID+"'>"+row.Category+"</option>";

			$("#categorysearch").append(item);

			});
		}
	}

// Get All Search Brands
function getSearchBrands(){

	$.ajax({
		type: 'GET',
		url: window.serverURL+"ws_brands.php",
		data: ({option :"1"}),

		dataType: 'json',
		timeout: 5000,
		success: function(data, textStatus, xhr)
		{

			if(data==0)
				alert("Data couldn't be loaded!")
			else{
				data = JSON.parse(xhr.responseText);

			populateSearchBrandsTable(data);
			}
		},
		error: function(xhr, status, errorThrown)
		{
			alert(status + errorThrown);
		}
	});  //

}

function populateSearchBrandsTable(data){

//data = data.users;
var item;

if(data.length>0){

	 $.each(data, function(index, row) {

	item="<option value='"+row.ID+"'>"+row.Name+"</option>";

	$("#brandssearch").append(item);

	});
}
}

// Get All Search Years
function getSearchYears(){

	$.ajax({
		type: 'GET',
		url: window.serverURL+"ws_cars.php",
		data: ({option :"6"}),

		dataType: 'json',
		timeout: 5000,
		success: function(data, textStatus, xhr)
		{

			if(data==0)
				alert("Data couldn't be loaded!")
			else{
				data = JSON.parse(xhr.responseText);

			populateSearchYearTable(data);
			}
		},
		error: function(xhr, status, errorThrown)
		{
			alert(status + errorThrown);
		}
	});  //

}

function populateSearchYearTable(data){

//data = data.users;
var item;

if(data.length>0){

	 $.each(data, function(index, row) {

	item="<option value='"+row.Year+"'>"+row.Year+"</option>";

	$("#yearsearch").append(item);

	});
}
}

// Get All Search Color
function getSearchColors(){

	$.ajax({
		type: 'GET',
		url: window.serverURL+"ws_cars.php",
		data: ({option :"7"}),

		dataType: 'json',
		timeout: 5000,
		success: function(data, textStatus, xhr)
		{

			if(data==0)
				alert("Data couldn't be loaded!")
			else{
				data = JSON.parse(xhr.responseText);

			populateSearchColorTable(data);
			}
		},
		error: function(xhr, status, errorThrown)
		{
			alert(status + errorThrown);
		}
	});  //

}

function populateSearchColorTable(data){

//data = data.users;
var item;

if(data.length>0){

	 $.each(data, function(index, row) {

	item="<option value='"+row.Color+"'>"+row.Color+"</option>";

	$("#colorsearch").append(item);

	});
}
}

// Get All Search Seats
function getSearchSeats(){

	$.ajax({
		type: 'GET',
		url: window.serverURL+"ws_cars.php",
		data: ({option :"8"}),

		dataType: 'json',
		timeout: 5000,
		success: function(data, textStatus, xhr)
		{

			if(data==0)
				alert("Data couldn't be loaded!")
			else{
				data = JSON.parse(xhr.responseText);

			populateSearchSeatTable(data);
			}
		},
		error: function(xhr, status, errorThrown)
		{
			alert(status + errorThrown);
		}
	});  //

}

function populateSearchSeatTable(data){

//data = data.users;
var item;

if(data.length>0){

	 $.each(data, function(index, row) {

	item="<option value='"+row.Seats+"'>"+row.Seats+"</option>";

	$("#seatssearch").append(item);

	});
}
}

$(document).on("click","[id^=cardetails]",function(){
	id=this.id.substring(10);
	localStorage.setItem("carid",id);
	location.href="viewcardetails.php";
});


});

$(".carbrand").hover(function(){

    $(".imagehover").css({
      "filter": "blur(1px)",
      "transform":"scale(1.1)"
    });

});
