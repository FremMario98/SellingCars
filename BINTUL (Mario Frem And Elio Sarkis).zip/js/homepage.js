// $(document).ready(function(){
//     $("#homepage").scroll(function(){
//         $(".navbar").css("display","none");
//     });
// });
//   if ($("#insidehomepage").scrollTop() < 20 ) {
//       $("#homecontent").css("display","none");
//   } else {
// $("#homecontent").css("display","block");
//   }


var scrollposition=0;
$("#insidehomepage").scroll(function () {

  var iCurScrollPos = $("#insidehomepage").scrollTop();
// console.log(iCurScrollPos);
        if (iCurScrollPos >scrollposition ) {
            // $("#homecontent").css({
            //   "transition": "1s linear",
            //   "display":"none"
            // });
            $("#homecontent").fadeOut();
        } else {
            $("#homecontent").css("display","block");
        }

});

$("#insidehomepage").mouseout(function() {
  $( "#navbarfixed" ).css("zIndex","0");
});
$("#insidehomepage").mouseover(function() {
  $( "#navbarfixed" ).css("zIndex","1");
});


$(".maindirectorypages").hover(function(){
	$(".maindirectorypages").css("width", "6%");
	$(this).css("width", "76%");
})

// Chart Js
var ctx = document.getElementById("myUsersChart");
var myChart = new Chart(ctx, {
  type: 'bar',
      data: {
        labels: ["Sept", "Oct", "Nov", "Dec", "Jan"],
        datasets: [
          {
            label: "Users (per Month)",
            backgroundColor: ["#3e95cd", "#999966","#99ccff","#9a3232","#8c8c8c"],
            data: [200,600,900,1000,2000]
          }
        ]
      },
      options: {
        legend: { display: false },
        title: {
          display: true,
          text: 'Users Signing Up'
        }
      }
  });

// Line Chart
  var ctx2 = document.getElementById("myProfitChart");
  var myChart2 = new Chart(ctx2, {
    type: 'line',
      data: {
        labels: ['January','February','March','April','May','June','July','August','September','October','November','December'],
        datasets: [{
            data: [86,114,106,106,400,1111,2133,3221,4783,5678,6800,7629],
            label: "Profit",
            borderColor: "#3e95cd",
            fill: false
          }
        ]
      },
      options: {
        title: {
          display: true,
          text: "Progress Of Website And It's Goal"
        }
      }
    });

// Doughnut
var ctx3 = document.getElementById("mySatisfactionChart");
var myChart3 = new Chart(ctx3, {
type: 'doughnut',
   data: {
     labels: ['Satisfied','Unsatisfied'],
     datasets: [
       {
         label: "Satisfaction",
         backgroundColor: [
             'rgba(255, 99, 132, 0.2)',
             'rgba(54, 162, 235, 0.2)'
         ],  borderColor: [
               'rgba(255,99,132,1)',
               'rgba(54, 162, 235, 1)'
           ],
            borderWidth: 1,
         data: [1899,101]
       }
     ]
   },
   options: {
     title: {
       display: true,
       text: 'Satisfaction / Buy'
     }
   }
});
