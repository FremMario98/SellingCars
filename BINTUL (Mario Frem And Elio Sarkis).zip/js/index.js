
window.serverURL = "http://localhost/finalproject/server_side/ws/";

// Ignored Characters Or Key Codes
  var ignore_key_codes=[9,49,106,107,109,191,192,186,189,187,220,222,221];

// For Email Prevent Few Characters Or Keys
$("#email").keydown(function(e){
  if($.inArray(e.keyCode, ignore_key_codes) >= 0){
      e.preventDefault();
   }
});

// For Password Prevent Few Characters Or Keys
$("#password").keydown(function(e){
  if($.inArray(e.keyCode, ignore_key_codes) >= 0){
      e.preventDefault();
   }
});

// For Confirm Password Prevent Characters
$("#confirmpassword").keydown(function(e){
  if($.inArray(e.keyCode, ignore_key_codes) >= 0){
      e.preventDefault();
   }
});

// For Confirm Username Prevent Characters Or Key Codes
$("#username").keydown(function(e){
  if($.inArray(e.keyCode, ignore_key_codes) >= 0){
      e.preventDefault();
   }
});

// For Confirm FirstName Prevent Characters Or Key Codes
$("#firstname").keydown(function(e){
  if($.inArray(e.keyCode, ignore_key_codes) >= 0){
      e.preventDefault();
   }
});

// For Confirm LastName Prevent Characters Or Key Codes
$("#lastname").keydown(function(e){
  if($.inArray(e.keyCode, ignore_key_codes) >= 0){
      e.preventDefault();
   }
});

// Verify Username If Exists
$("#username").keyup(function(e){
  verifyifusernameexist();
});

// Verify Email If Exists
$("#registeremail").keyup(function(e){
  verifyifemailexist();
});

// Verify If Passswords Match
$("#confirmpassword").keyup(function(e){
  verifyispassmatch();
});

$("#registerbutton").on("click",function(){

  $("#toggletoregister").addClass("rotate90");

window.location.href="register.php";

});

$("#loginbuttonlogin").on("click",function(){
  window.location.href="index.php";
});

// Login To Username(Or Email) And Password
// $("#loginbutton").on("click",function(){
//     verifyUser();
// });

// Register New User
$("#registersignup").on("click",function(){
  var empty=verifyifinputfieldempty();
  if(empty==false){
    var username=$("#usernameexists");
    var email=$("#emailexists");
    var passwordexists=$(".fontcolorred").length;
    if(username.length || email.length || passwordexists){
      alert("Missing Fields, Please Input The All Fields");
    }
    else{
    registernewuser();
    }
  }
  else if(empty==true){
      alert("Missing Fields, Please Input The All Fields");
  }
});


// Verify User And Password
// function verifyUser(){
//
//     let usern=$("#email").val();
//     let pass=$("#password").val();
//
// 		   $.ajax({
// 			  type: 'GET',
// 			  url: window.serverURL+"ws_users.php",
// 			  data: ({option :"1",credential:usern,password:pass}),
//
// 			  dataType: 'json',
// 			  timeout: 5000,
// 			  success: function(data, textStatus, xhr)
// 			  {
// 				  if(data==0)
// 					  {
//               $("#email").css("border","1px solid red");
//               $("#password").css("border","1px solid red");
//               if(!$("#appendhereiferror div").hasClass("errorverifyup")){
//               $("#appendhereiferror").append("<div class='col-10 errorverifyup'>Invalid Username Or Password</div>");
//             }
//             }
// 				  else{
// 				  	data = JSON.parse(xhr.responseText);
//             window.location.href="home.php";
// 				  }
// 			  },
// 			  error: function(xhr, status, errorThrown)
// 			  {
// 				  alert(status + errorThrown);
// 			  }
// 		  });  //
//
// 	}

// Verify If All Input Fields Are Empty
function verifyifinputfieldempty(){
  var ifempty=false;
  $("input").each(function(){
    if($(this).val()==""){
      ifempty=true;
    }
    });
    return ifempty;
}

// Register New User
function registernewuser(){

  var username=$("#username").val();
  var phone=$("#phonenumber").val();
  var firstname=$("#firstname").val();
  var lastname=$("#lastname").val();
  var email=$("#registeremail").val();
  var password=$("#password").val();

  $.ajax({
    type:'GET',
    url:window.serverURL+"ws_users.php",
    // userAdd($_GET["firstName"], $_GET["lastName"], $_GET["phone"], $_GET["email"], $_GET["username"], $_GET["password"]);
    data:({option:"5",firstName:firstname,lastName:lastname,phone:phone,email:email,username:username,password:password}),

    dataType:'json',
    timeout:5000,
    success:function(data,textStatus,xhr){
      window.location.href="index.php";
    },
    error:function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });
}

// Verify Username If Exists
function verifyifusernameexist(){

  var username=$("#username").val();

  $.ajax({
    type:'GET',
    url:window.serverURL+"ws_users.php",
    data:({option:"2",username:username}),

    dataType:'json',
    timeout:5000,
    success:function(data,textStatus,xhr){
      if(data==1){
        $("#username").css("color","red");
        if(!$("#usernameexists").length){
        $("<span id='usernameexists' class='fontcolorred'> Exists</span>").insertAfter("#usernamelabel");
        }
      }
      else if(data==0){
        $("#username").css("color","black");
        $("#usernameexists").remove();
      }
    },
    error:function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });

}

// Verify If Email Exists
function verifyifemailexist(){

    var email=$("#registeremail").val();

  $.ajax({
    type:'GET',
    url:window.serverURL+"ws_users.php",
    data:({option:"3",email:email}),

    dataType:'json',
    timeout:5000,
    success:function(data,textStatus,xhr){
      if(data==1){
        $("#registeremail").css("color","red");
        if(!$("#emailexists").length){
        $("<span id='emailexists' class='fontcolorred'> Exists</span>").insertAfter("#emailexistslabel");
        }
      }
      else if(data==0){
        $("#registeremail").css("color","black");
        $("#emailexists").remove();
      }
    },
    error:function(xhr, status, errorThrown)
    {
      alert(status + errorThrown);
    }
  });
}

// Verify If Passwords Match
function verifyispassmatch(){
  if($("#confirmpassword").val()==$("#password").val() ||($("#confirmpassword").val().lenght==0 && $("#password").val().length==0) ){
    $("#confirmpassword").css("color","black");
    $("#password").css("color","black");
    $(".fontcolorred").remove();
  }
  else{
    $("#confirmpassword").css("color","red");
    $("#password").css("color","red");
    if(!$(".fontcolorred").length){
    $("<span class='fontcolorred'> Passwords Don't Match</span>").insertAfter(".nomatchpassword");
  }
  }
}
