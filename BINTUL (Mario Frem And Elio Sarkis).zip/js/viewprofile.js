//
// $(document).ready(function(){
//
//   window.serverURL = "http://localhost/finalproject/server_side/ws/";
//   getCurrentUser();
//
//   $("#savecuruserchange").on("click",function(){
//       updateCurrentUser();
//   });
//
//   function getCurrentUser(){
//
//         let id=2;
//
//   		  $.ajax({
//   			  type: 'GET',
//   			  url: window.serverURL+"ws_users.php",
//   			  data: ({option :"10",id:id}),
//
//   			  dataType: 'json',
//   			  timeout: 5000,
//   			  success: function(data, textStatus, xhr)
//   			  {
//
//   				  if(data==0)
//   					  alert("Data couldn't be loaded!")
//   				  else{
//   				  	data = JSON.parse(xhr.responseText);
//
//               let fullname=$("#currproffullname").text(data[0].FirstName+" "+data[0].LastName);
//               let phonenumber=$("#currprofphone").text(data[0].Phone);
//               let email=$("#currprofemail").text(data[0].Email);
//               let username=$("#currprofusername").text(data[0].Username);
//
//               let firstnamemodal=$("#modalfname").val(data[0].FirstName);
//               let lastnamemodal=$("#modallname").val(data[0].LastName);
//               let phonenumbermodal=$("#modalphone").val(data[0].Phone);
//               let emailmodal=$("#modalemail").val(data[0].Email);
//               let usernamemodal=$("#exampleModalLongTitle").text(data[0].Username);
//
//   				  }
//   			  },
//   			  error: function(xhr, status, errorThrown)
//   			  {
//   				  alert(status + errorThrown);
//   			  }
//   		  });  //
//
//   	}
//
//
//
// function updateCurrentUser(){
//
//       let id=2;
//       let firstname=$("#modalfname").val();
//       let lastname=$("#modallname").val();
//       let phonenumber=$("#modalphone").val();
//       let email=$("#modalemail").val();
//
//       $.ajax({
//         type: 'GET',
//         url: window.serverURL+"ws_users.php",
//         // $_GET["id"], $_GET["firstName"], $_GET["lastName"], $_GET["phone"], $_GET["email"]
//         data: ({option :"11",id:id,firstName:firstname,lastName:lastname,phone:phonenumber,email:email}),
//
//         dataType: 'json',
//         timeout: 5000,
//         success: function(data, textStatus, xhr)
//         {
//
//           if(data==0)
//             alert("Data couldn't be loaded!")
//           else{
//             data = JSON.parse(xhr.responseText);
//
//             getCurrentUser(id);
//
//           }
//         },
//         error: function(xhr, status, errorThrown)
//         {
//           alert(status + errorThrown);
//         }
//       });  //
//
//   }
//
//
//   $("#messageicon").on("click",function(){
//     if($("#messagedialog").css("right")=="-1300px")
//     {$("#messagedialog").css("right","0%");}
//     else{
//       $("#messagedialog").css("right","-1300px");
//     }
//
//   });
//
//
// });
