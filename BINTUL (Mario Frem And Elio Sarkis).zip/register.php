<?php
  // Start Session
  session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
<link rel="stylesheet" href="Links\bootstrap.min.css" >
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="Links\bootstrap.min.js" ></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/index.css" type="text/css"/>
  </head>

  <body>
<div class="container">

<div class="row formlogin justify-content-center align-items-center">

  <div class="col-md-5 mainform mainformregister" style="background-color:transparent;">

    <div class="row justify-content-center marginalllogin">
      <div class="col-md-6 col-11">
        <label for="firstname" style="color:white;">First Name</label>
        <input type="text" id="firstname" class="col-md-12 form-control" placeholder="FirstName" minlength="3" maxlength="35" required/>
      </div>
      <div class="col-md-6 col-11">
          <label for="lastname" style="color:white;">Last Name</label>
        <input type="text" id="lastname" class="col-md-12 form-control" placeholder="LastName" minlength="3" maxlength="35" required/>
      </div>
    </div>
    <div class="row justify-content-center marginalllogin">
      <div class="col-md-6 col-11">
        <label id="usernamelabel" for="username" style="color:white;">Username</label>
        <input type="text" id="username" class="col-md-12 form-control" placeholder="Username" minlength="3" maxlength="35" required/>
      </div>
      <div class="col-md-6 col-11">
        <label for="phonenumber" style="color:white;">Phone</label>
        <input type="number" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
    maxlength = "8" id="phonenumber" class="col-md-12 form-control" placeholder="961" required/>
      </div>
    </div>

    <div class="row justify-content-center marginalllogin">
      <div class="col-md-12 col-11">
        <label id="emailexistslabel" for="email" style="color:white;">Email</label>
          <input type="email" id="registeremail" class="col-md-12 form-control op1" placeholder="user@outlook.com" minlength="3" maxlength="35" required/>
      </div>
    </div>
    <div class="row justify-content-center marginalllogin">
      <div class="col-md-12 col-11">
          <label class="nomatchpassword" for="password" style="color:white;">Password</label>
          <input type="password" id="password" class="col-md-12 form-control op1" placeholder="Password" required/>
      </div>
    </div>
    <div class="row justify-content-center marginalllogin">
      <div class="col-md-12 col-11">
          <label class="nomatchpassword" for="confirmpassword" style="color:white;">Confirm Password</label>
          <input type="password" id="confirmpassword" class="col-md-12 form-control op1" placeholder="Confirm Password" required/>
      </div>
    </div>
    <div class="row justify-content-center marginallregister">
      <div class="col-md-5 col-5">
          <button type="button" id="loginbuttonlogin" class="btn btn-primary col-md-12">Back</button>
      </div>
      <div class="col-md-5 col-5 offset-md-2">
          <button type="submit" id="registersignup" class="btn btn-primary col-md-12">Register</button>
      </div>
    </div>

  </div>

  <!-- BackFace Visibility -->

  </div>


</div>


<script src="js\index.js"></script>
  </body>
</html>
