<?php

require_once('C:/wamp64/www/FinalProject/server_side/dal_util/DAL.class.php');

// Cars management class.
class car {

	// Private variables needed to create a new object of type 'car' and needed in functions that follow.
	private $_db;
	private $_cId;
	private $_cName;
	private $_cDescription;
	private $_cBId;
	private $_cCatId;
	private $_cYear;
	private $_cColor;
	private $_cSeats;
	private $_cPrice;
	private $_cAvailable;


	// Public functions to construct and destruct objects of type 'car'.
	public function __construct() {
		$this->_db = new DAL();
	}

	public function __destruct() {
		$this->_db = null;
	}


	// Public functions to return specific variables from the object of type 'car'.
	public function getCID() {
		return $this->_cId;
	}

	public function getCname() {
		return $this->_cName;
	}

	public function getCDescription() {
		return $this->_cDescription;
	}

	public function getCBId() {
		return $this->_cBId;
	}

	public function getCCatId() {
		return $this->_cCatId;
	}

	public function getCYear() {
		return $this->_cYear;
	}

	public function getCColor() {
		return $this->_cColor;
	}

	public function getCSeats() {
		return $this->_cSeats;
	}

	public function getCPrice() {
		return $this->_cPrice;
	}

	public function getCAvailable() {
		return $this->_cAvailable;
	}


	// Public functions used to ensure website's full functionality and connectivity between front-end and back-end.
	public function carPopulate() {
		$sqlQuery = "SELECT c_id AS 'ID', b_name AS 'Brand', cat_name AS 'Category', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_seats AS 'NumberofSeats', c_price AS 'Price', av_description AS 'Status' FROM brands, categories, cars, available WHERE c_b_id=b_id AND c_cat_id=cat_id AND c_available=av_value;";

		try {
			$data = $this->_db->getData($sqlQuery);

			return $data;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

	public function carAdd($name, $description, $brand, $category, $year, $color, $seats, $price) {
		$sqlQuery = "INSERT INTO cars VALUES (NULL, '$name', '$description', '$brand', '$category', '$year', '$color', '$seats', '$price', 1);";

		try {
			$data = $this->_db->executeQuery($sqlQuery);

			return 1;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

	public function carUpdate($id, $name, $description, $brand, $category, $year, $color, $seats, $price, $active) {
		$sqlQuery = "UPDATE cars SET c_name='$name', c_description='$description', c_b_id='$brand', c_cat_id='$category', c_year='$year', c_color='$color', c_seats='$seats', c_price='$price', c_available='$active' WHERE c_id=$id";

		try {
			$data = $this->_db->executeQuery($sqlQuery);

			return 1;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

	public function carSetSold($id) {
		$sqlQuery = "UPDATE cars SET c_available=0 WHERE c_id=$id;";

		try {
			$data = $this->_db->executeQuery($sqlQuery);

			return 1;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

// Get Current Car
public function currentcarallinfo($id) {
	$sqlQuery = "SELECT c_id AS 'ID', brands.b_id AS 'Brand', categories.cat_id AS 'Category', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_seats AS 'NumberofSeats', c_price AS 'Price', c_available AS 'Status' FROM cars, brands , categories WHERE c_available=1 And categories.cat_id=cars.c_cat_id AND brands.b_id=cars.c_b_id AND c_id=$id ;";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}
public function currentcarallinfoGeneral($id) {
	$sqlQuery = "SELECT c_id AS 'ID', brands.b_name AS 'Brand', categories.cat_name AS 'Category', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_seats AS 'NumberofSeats', c_price AS 'Price', c_available AS 'Status' FROM cars, brands , categories WHERE categories.cat_id=cars.c_cat_id AND brands.b_id=cars.c_b_id AND c_id=$id ;";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// Get Car Distinct Years
public function distinctcaryear() {
	$sqlQuery = "select DISTINCT(c_year) AS 'Year' from cars;";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// Get Distinct Car Color
public function distinctcarcolor() {
	$sqlQuery = "select DISTINCT(c_color) AS 'Color' from cars; ";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// Get Distinct Car Number Of Seats
public function distinctcarnumseats() {
	$sqlQuery = "select DISTINCT(c_seats) AS 'Seats'  from cars; ";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}



// search for cars
public function searchforcars($brand='',$category='',$year='',$color='',$seats='',$available='') {
	$sqlQuery = "SELECT c_id AS 'ID', b_name AS 'Brand', cat_name AS 'Category', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_seats AS 'NumberofSeats', c_price AS 'Price', av_description AS 'Status' FROM brands, categories, cars, available WHERE c_b_id=b_id AND c_cat_id=cat_id AND c_available=av_value AND b_name LIKE '%$brand%' AND cat_name like '%$category %' AND c_year LIKE '%$year%' AND c_color LIKE '%$color%' AND c_seats LIKE '%$seats%' AND av_description LIKE '%$available%';";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// Model Cars Count
public function modalcarcount() {
	$sqlQuery = "SELECT c_year AS 'Year', COUNT(c_year) AS 'Count' from cars, sales WHERE cars.c_id=sales.s_c_id GROUP BY c_year ASC ";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}


// Current Car Review
public function currentcarreview($carid) {
	$sqlQuery = "select u_username AS 'UserName', commentoncar.comment AS 'Comment' from users, commentoncar, cars WHERE commentoncar.car_id=cars.c_id AND commentoncar.user_id=users.u_id AND cars.c_id=$carid;";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// SELECT c_id AS 'ID', b_name AS 'Brand', cat_name AS 'Category', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_seats AS 'NumberofSeats', c_price AS 'Price', av_description AS 'Status' FROM brands, categories, cars, available WHERE c_b_id=b_id AND c_cat_id=cat_id AND( c_available=av_value and b_name LIKE "%BMW%" AND cat_name like "%%" AND c_year LIKE "%%" AND c_color LIKE "%%" AND c_seats LIKE "%%" AND av_description LIKE "%%");
	// End of cars management class.
}

?>
