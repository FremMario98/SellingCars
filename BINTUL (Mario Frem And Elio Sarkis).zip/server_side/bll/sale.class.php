<?php

require_once('C:/wamp64/www/FinalProject/server_side/dal_util/DAL.class.php');

// Sales management class.
class sale {

	// Private variables needed to create a new object of type 'sale' and needed in functions that follow.
	private $_db;
	private $_sId;
	private $_sCId;
	private $_sUId;
	private $_sDate;


	// Public functions to construct and destruct objects of type 'sale'.
	public function __construct() {
		$this->_db = new DAL();
	}

	public function __destruct() {
		$this->_db = null;
	}


	// Public functions to return specific variables from the object of type 'sale'.
	public function getSID() {
		return $this->_sId;
	}

	public function getSCID() {
		return $this->_sCId;
	}

	public function getSUID() {
		return $this->_sUId;
	}

	public function getSDate() {
		return $this->_sDate;
	}


	// Public functions used to ensure website's full functionality and connectivity between front-end and back-end.
	public function salePopulate() {
		$sqlQuery = "SELECT s_id AS 'ID', concat(u_fname, ' ', u_lname) AS 'Buyer', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_price AS 'Price', s_date AS 'DateBought' FROM sales, users, cars WHERE s_u_id=u_id AND s_c_id=c_id;";

		try {
			$data = $this->_db->getData($sqlQuery);

			return $data;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

	public function saleAdd($carId, $userId) {
		$sqlQuery = "INSERT INTO sales VALUES (NULL, '$carId', '$userId', CURRENT_DATE);";

		try {
			$data = $this->_db->executeQuery($sqlQuery);

			return 1;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

	// Get All Cars Sales By Months
	public function saleGetByMonth() {
		$sqlQuery = "SELECT s_id AS 'ID', concat(u_fname, ' ', u_lname) AS 'Buyer', c_name AS 'Name', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_price AS 'Price', SUBSTRING(s_date, 6, 2) AS 'DateBought' FROM sales, users, cars WHERE s_u_id=u_id AND s_c_id=c_id; ";

		try {
			$data = $this->_db->getData($sqlQuery);

			return $data;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

// Get Reservations By User
	public function saleByUser($userid) {
		$sqlQuery = "SELECT DISTINCT s_id AS 'ID', c_name AS 'CarName', c_description AS 'Description', c_year AS 'Year', c_color AS 'Color', c_price AS 'Price',c_seats As 'Seats',b_name AS 'Brand', cat_name AS 'Category', av_description AS 'Status', s_date AS 'DateBought' FROM sales , users, cars, brands , categories, available WHERE s_u_id=$userid AND s_c_id=c_id AND c_b_id=b_id AND c_cat_id=cat_id AND c_available=av_value; ";

		try {
			$data = $this->_db->getData($sqlQuery);

			return $data;
		}
		catch(Exception $ex) {
			throw $ex;
		}
	}

// Get Full Name With Quantity
public function bestsalesByFiveUser() {
	$sqlQuery = "SELECT COUNT(concat(u_fname, ' ', u_lname)) AS 'CarsBought',concat(u_fname, ' ', u_lname) AS 'FullName' FROM sales, users, cars WHERE s_u_id=u_id AND s_c_id=c_id GROUP BY s_u_id ORDER BY CarsBought DESC LIMIT 5";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// Most Cars Bought
public function MostCarsBought() {
	$sqlQuery = "SELECT COUNT(c_name) AS 'CarsBought',c_name AS 'CarName' FROM sales, users, cars WHERE s_u_id=u_id AND s_c_id=c_id GROUP BY s_c_id ORDER BY CarsBought DESC LIMIT 5; ";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

// Sum Of Sold Cars
public function SumBought() {
	$sqlQuery = "SELECT SUM(c_price) AS 'Price' FROM sales, users, cars WHERE s_u_id=u_id AND s_c_id=c_id;";

	try {
		$data = $this->_db->getData($sqlQuery);

		return $data;
	}
	catch(Exception $ex) {
		throw $ex;
	}
}

}

?>
