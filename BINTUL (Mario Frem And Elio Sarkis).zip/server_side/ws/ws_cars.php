<?php

require_once('C:/wamp64/www/FinalProject/server_side/bll/car.class.php');

// Web service to manage all tasks related to cars data.
// Variables needed
$car = new car();
$result;

try {
	if(isset($_GET["option"])) {
		$option = $_GET["option"];

		switch($option) {
			// Populate cars table
			case 1:
				$result = $car->carPopulate();

				break;

			// Add car
			case 2:
				$result = $car->carAdd($_GET["car"]);

				break;

			// Update car
			case 3:
				$result = $car->carUpdate($_GET["id"], $_GET["name"],$_GET["description"],$_GET["brand"],$_GET["category"],$_GET["year"],$_GET["color"],$_GET["seats"],$_GET["price"], $_GET["active"]);

				break;

			// Set car as inactive
			case 4:
				$result = $car->carSetSold($_GET["id"]);

				break;
		// Get Current Car Information
		case 5:
			$result = $car->currentcarallinfo($_GET["id"]);

			break;

		// Get Distinct Year Made Car
		case 6:
			$result = $car->distinctcaryear();

			break;

		// Get Distinct Color Of Cars
		case 7:
				$result = $car->distinctcarcolor();

				break;

			// Get Distinct Number Of Seats
			case 8:
				$result = $car->distinctcarnumseats();

				break;

			// Get General Car Details Info
			case 9:
				$result = $car->currentcarallinfoGeneral($_GET["id"]);

				break;

			// Search For Cars
			case 10:
				$result=$car->searchforcars($_GET["brand"],$_GET["category"],$_GET["year"],$_GET["color"],$_GET["seats"],$_GET["available"]);

				break;

			// Get Car By Model Years And Count
			case 11:
				$result=$car->modalcarcount();

				break;

			// Current Car Reviews
			case 12:
				$result=$car->currentcarreview($_GET["carid"]);

				break;

		}
	}

	header("Content-type:application/json");
	echo json_encode($result);
}
catch(Exception $ex) {
	echo -1;
}

// End of cars management web service.

?>
