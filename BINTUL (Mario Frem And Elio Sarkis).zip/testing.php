<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="Links\bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="Links\bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet"  type="text/css" href="css\animate.css" >
    <link rel="stylesheet" href="css\ViewMoreDetails.css">
<!-- Not All The jQuery Are Downloaded So We Put jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  </head>
  <body style="overflow:hidden;">

    <div class="col-md-1" id="sidebar">
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-angle-double-right itemicon"></i></a>
        <!-- <i class="fas fa-arrow-right"></i> -->
      </div>
      <div class="col-md-12" id="divprofileimage">
        <a href="#"><img src="Images\koenigsegg.jpg" id="profileimage"/></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-search itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-home itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-bookmark itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-car-alt itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:100%;height:100%;"></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#" id="messageicon"><i class="far fa-comments itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem" id="logoutbutton">
        <a href="#"><i class="fas fa-door-open itemicon"></i></a>
      </div>
    </div>

    <div class="col-md-10 col-10 offset-1 offset-md-2" id="maincarcover">

      <div class="col-md-8 col-12" id="divcars">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="Images\koenigsegg.jpg" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="Images\backgroundlogin.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="Images\carbrands.jpg" alt="Third slide">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>

        <div class="col-md-12">
          <div class="col-md-12 col-12 displayflex textaligncenter">
             <h4><i class="fas fa-info-circle"></i> Description</h4>
           </div>
           <div class="col-md-12 col-12 displayflex textaligncenter">
             <p id="cardescriptioninfo"></p>
           </div>
       </div>

      </div>

      <div class="col-md-4">

      <div class="col-md-12" id="carnametitle">
        <h1 id="carnameinfo">Car Name</h1>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-5 col-6 offset-1 offset-md-1" id="carbrandinfo"></div>
        <div class="col-md-5 col-6 offset-1 offset-md-1" id="cartypeinfo"></div>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-5 col-6 offset-1 offset-md-1" id="caryearinfo"></div>
        <div class="col-md-6 col-6 " id="carcolorinfo"></div>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-12 col-10 offset-1 offset-md-1" id="carnumseatsinfo"></div>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <button class="btn btn-primary col-md-12" id="buycurrentcar">Buy <i class="fas fa-hand-holding-usd"></i></button>
      </div>

      <div class="col-md-12 col-12 displayflex textaligncenter" id="pricetitle">
         <div class="col-md-12">
           <h4><i class="fas fa-money-check-alt"></i> Price </h4>
         </div>
       </div>
       <div class="col-md-12 col-12 displayflex textaligncenter">
         <div class="col-md-12 col-12" id="carpricedescription"></div>
       </div>

      </div>
</div>
<div class="col-md-5" id="messagedialog">

<div class="col-md-12 mainmessagedialogbox">
  <div class="col-md-12">
    <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
  <h3>Username</h3>
  <p>udfludsagfdlisfglasduifgaldsufgasdfgaliudfasifl<br/>ifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
  </div>
</div>

<div class="col-md-12 mainmessagedialogbox">
  <div class="col-md-12">
    <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
  <h3>Username</h3>
  <p>udfludsagfdlisfglasduifgaldsufgasdfgaliudfasifl<br/>ifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
  </div>
</div>

<div class="col-md-12 mainmessagedialogbox">
  <div class="col-md-12">
    <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
  <h3>Username</h3>
  <p>udfludsagfdlisfglasduifgaldsufgasdfgaliudfasifl<br/>ifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
  </div>
</div>

</div>

<script type="text/javascript" src="js\cardetails.js">

</script>
  </body>
</html>
