<?php
  // Start Session
  session_start();
  // $_SESSION["uid"];
  $userid=$_SESSION["uid"];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="Links\bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="Links\bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet"  type="text/css" href="css\animate.css" >
    <link rel="stylesheet" href="css\ViewMoreDetails.css">
<!-- Not All The jQuery Are Downloaded So We Put jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  </head>
  <body style="overflow:hidden;overflow-y:scroll;">

    <div class="col-md-1" id="sidebar">
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-angle-double-right itemicon"></i></a>
        <!-- <i class="fas fa-arrow-right"></i> -->
      </div>
      <div class="col-md-12" id="divprofileimage">
        <a href="viewprofile.php"><img src="Images\koenigsegg.jpg" id="profileimage"/></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="home.php"><i class="fas fa-home itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="Reservation\myreservation.php"><i class="fas fa-bookmark itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="cars.php"><i class="fas fa-car-alt itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="carbrands.php"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:100%;height:100%;"></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#" id="messageicon"><i class="far fa-comments itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem" id="logoutbutton">
        <a href="index.php"><i class="fas fa-door-open itemicon"></i></a>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light d-block d-sm-none navbarsidebar">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent2">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
              <a href="home.php"><i class="fas fa-home itemicon"></i> <span class="navbarforsidebar">Home</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><i class="fas fa-bookmark itemicon"></i> <span class="navbarforsidebar">Bookmark</span></a>
          </li>
          <li class="nav-item active">
            <a href="cars.php"><i class="fas fa-car-alt itemicon"></i> <span class="navbarforsidebar">View Cars</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:40px;margin-top:15px;"> <span class="navbarforsidebar">Brands</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="freedommessageicon"><i class="far fa-comments itemicon"></i> <span class="navbarforsidebar">FreedomMessage</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="logoutbutton"><i class="fas fa-door-open itemicon"></i> <span class="navbarforsidebar">Logout</span></a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="col-md-10 col-12  offset-md-2" id="maincarcover">

      <div class="col-md-8 col-12" id="divcars">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="Images\koenigsegg.jpg" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="Images\backgroundlogin.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="Images\carbrands.jpg" alt="Third slide">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>

      <div class="col-md-4">

      <div class="col-md-12" id="carnametitle">
        <h1 id="carnameinfo">Car Name</h1>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-5 col-6 offset-1 offset-md-1" id="carbrandinfo"></div>
        <div class="col-md-5 col-6 offset-1 offset-md-1" id="cartypeinfo"></div>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-5 col-6 offset-1 offset-md-1" id="caryearinfo"></div>
        <div class="col-md-6 col-6" id="carcolorinfo"></div>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-12 col-10 offset-1 offset-md-1" id="carnumseatsinfo"></div>
      </div>

      <div class="col-md-12 col-12 displayflex">
        <button class="btn btn-primary col-md-12" data-toggle="modal" data-target="#BuyCurrentCar" id="buycurrentcar">Buy <i class="fas fa-hand-holding-usd"></i></button>
      </div>

      </div>

    <div class="col-md-12 col-12 textaligncenter">

      <div class="col-md-12 col-12 displayflex">
        <div class="col-md-8 col-12">
           <h4><i class="fas fa-info-circle"></i> Description</h4>
         </div>
         <div class="col-md-4" id="pricetitle">
            <h4><i class="fas fa-money-check-alt"></i> Price </h4>
          </div>
      </div>

      <div class="col-md-12 col-12 displayflex" id="extradetailsinfo">

         <div class="col-md-6 col-12 offset-md-1">
           <p id="cardescriptioninfo"></p>
         </div>

         <div class="col-12" id="pricetitle2">
            <h4>Price</h4>
          </div>
         <div class="col-md-4 col-12 offset-md-1" id="carpricedescription"></div>
      </div>

      <div class="col-md-12 col-12" id="reviewsoncar">
        <h1>Reviews <i class="fas fa-chalkboard-teacher"></i></h1>
           <div class="col-md-12 mainmessagedialogbox">
              <div class="col-md-12">
                <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
                <h3 class="h3sizeifsmall">Username</h3>
                <p class="wordbrkpar">udfludsagfdlisfglasduifgaldsufgasdfgaliudfasiflifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
              </div>
          </div>

          <div class="col-md-12 col-12" style="display:flex;">
            <div class="col-md-2 col-4" style="align-self:center;">
              <img src="Images/backgroundlogin.jpg" alt="Reload For Profile Image" class="imageofmessagedialog">
            </div>
            <div class="col-md-9 col-8" id="textareadivpar">
              <textarea name="" id="textareapar" placeholder="Add A Comment ..."></textarea>
            </div>
          </div>

          <div class="col-md-6 offset-md-3 col-12">
            <button class="btn btn-primary col-md-12" id="commentoncar">Leave A Comment <i class="fas fa-truck-moving"></i></button>
          </div>

      </div>

    </div>

    <!-- Modal -->
      <div class="modal fade" id="BuyCurrentCar" tabindex="-1" role="dialog" aria-labelledby="CurrentCarTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">

            <div class="modal-body">
              <div class="col-md-12 displayflex">
                <div class="col-md-6">
                  <h3> CONGRATS?
                </div>
                <div class="col-md-6">
                  <div class="col-md-12" id="currentcarpricebuy">Price</div>
                  <div class="col-md-12" id="currentcarnamebuy">Car Name</div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
              <button type="button" class="btn btn-primary" id="buycurrentcarnow">Buy Now</button>
            </div>
          </div>
        </div>
      </div>

    </div>

    <div class="col-md-5" id="messagedialog"></div>

<script type="text/javascript" src="js\cardetails.js"></script>
<!-- <script type="text/javascript"> -->
  <!-- try{
    var name= ;

    $("#buycurrentcar").prop('disabled', false);
  }
  catch(err){
        $("#buycurrentcar").prop('disabled', true);
  }

</script> -->
<script type="text/javascript">

  var carid= JSON.parse(localStorage.getItem('carid'));

$( document ).ready(function() {

window.serverURL = "http://localhost/finalproject/server_side/ws/";

    getCarInfo();
    getCurrentCarReview();

// Function Get Car Details
function getCarInfo(){

      // var id=$_SESSION["currencarid"];
      // var carid=parseInt(localStorage.getItem("carid"));


		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_cars.php",
			  data: ({option :"9",id:carid}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data==0)
					  alert("Data couldn't be loaded!")
				  else{
				  	data = JSON.parse(xhr.responseText);

            var carname=$("#carnameinfo");
            var carbrand=$("#carbrandinfo");
            var cartype=$("#cartypeinfo");
            var carnumseat=$("#carnumseatsinfo");
            var cardescription=$("#cardescriptioninfo");
            var carprice=$("#carpricedescription");
            var caryear=$("#caryearinfo");
            var carcolor=$("#carcolorinfo");

            carname.text(data[0].Name);
            carbrand.text(data[0].Brand);
            cartype.text(data[0].Category);
            cardescription.text(data[0].Description);
            caryear.text(data[0].Year);
            carcolor.text(data[0].Color);
            carnumseat.text("Maximum "+data[0].NumberofSeats +" Passengers Relaxed");
            carprice.text(data[0].Price);

            $("#currentcarpricebuy").text(data[0].Price);
            $("#currentcarnamebuy").text(data[0].Name);

            // If User Exists
            var userexist= '<?php echo isset($_SESSION["uid"]) ;?>';
            if(data[0].Status==0 || userexist.length==0){
              $("#buycurrentcar").prop('disabled', true);
            }
            else{
              $("#buycurrentcar").prop('disabled', false);
            }

				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}


  $("#buycurrentcarnow").on("click",function(){
        buyCurrentCar();
  });

// Buy Car
function buyCurrentCar(){

      // var id=$_SESSION["currencarid"];
      // var carid=parseInt(localStorage.getItem("carid"));

      var userid='<?php echo $userid; ?>';

		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_sales.php",
			  data: ({option :"2",carId:carid,userId:userid}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data==0)
					  alert("Data couldn't be loaded!")
				  else{
				  	data = JSON.parse(xhr.responseText);
            setCurrentCarSold();
				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}
  // Set Car Sold
  function setCurrentCarSold(){

        // var id=$_SESSION["currencarid"];
        // var carid=parseInt(localStorage.getItem("carid"));


  		  $.ajax({
  			  type: 'GET',
  			  url: window.serverURL+"ws_cars.php",
  			  data: ({option :"4",id:carid}),

  			  dataType: 'json',
  			  timeout: 5000,
  			  success: function(data, textStatus, xhr)
  			  {

  				  if(data==0)
  					  alert("Data couldn't be loaded!")
  				  else{
  				  	data = JSON.parse(xhr.responseText);
              window.location.href="cars.php";
  				  }
  			  },
  			  error: function(xhr, status, errorThrown)
  			  {
  				  alert(status + errorThrown);
  			  }
  		  });  //

  	}





  $("#messageicon").on("click",function(){
    if($("#messagedialog").css("right")=="-1300px")
  	{
      $("#messagedialog").css("right","0%");
      getComments();
    }
    else{
      $("#messagedialog").css("right","-1300px");
      $("#messagedialog").empty();
    }

  });

  getComments();

  function getComments(){

        $.ajax({
          type: 'GET',
          url: window.serverURL+"ws_freedomreviews.php",
          data: ({option :"1"}),

          dataType: 'json',
          timeout: 5000,
          success: function(data, textStatus, xhr)
          {

            if(data<=0)
              alert("Data couldn't be loaded!")
            else{
              data = JSON.parse(xhr.responseText);

            populateComments(data);
            }
          },
          error: function(xhr, status, errorThrown)
          {
            alert(status + errorThrown);
          }
        });  //

    }

  function populateComments(data){

      var item;

      if(data.length>0){

         $.each(data, function(index, row) {

          item= `
          <div class="col-md-12 mainmessagedialogbox">
            <div class="col-md-12">
              <img src="Images\\koenigsegg.jpg" class="imageofmessagedialog"/>
            <h3 class="h3sizeifsmall">`+row.UserName+`</h3>
            <p class="wordbrkpar">`+row.Comment+`</p>
            </div>
          </div>
          `;

        // $("#reviewscontainer").prepend(item);
        $("#messagedialog").prepend(item);

        });

      }
    }


// Get Car Reviews
function getCurrentCarReview(){



      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_cars.php",
        data: ({option :"12",carid:carid}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data<=0)
            console.log("No Reviews");
          else{
            data = JSON.parse(xhr.responseText);

          populateCurrentCarReviews(data);
          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }

  function populateCurrentCarReviews(data){

    var item;

    if(data.length>0){

       $.each(data, function(index, row) {

        item= `
        <div class="col-md-12 mainmessagedialogbox">
        <div class="col-md-12">
          <img src="Images\\koenigsegg.jpg" class="imageofmessagedialog"/>
          <h3>`+row.UserName+`</h3>
          <p>`+row.Comment+`</p>
        </div>
        </div>
        `;

      // $("#reviewscontainer").prepend(item);
      $("#reviewsoncar").append(item);

      });

    }

  }


    $("#logoutbutton").on("click",function(){

      window.location="../index.php";
    });


});


$("#logoutbutton").on("click",function(){
  logoutcurruser();
});

// Logout
function logoutcurruser(){

		  $.ajax({
			  type: 'GET',
			  url: window.serverURL+"ws_users.php",
			  data: ({option :"9"}),

			  dataType: 'json',
			  timeout: 5000,
			  success: function(data, textStatus, xhr)
			  {

				  if(data==0)
					  alert("Data couldn't be loaded!")
				  else{
				        window.location.href="index.php";
				  }
			  },
			  error: function(xhr, status, errorThrown)
			  {
				  alert(status + errorThrown);
			  }
		  });  //

	}

  $("#freedommessageicon").on("click",function(){
    window.location.href="Reviews@ndComments\\comment.php";
  });

</script>
  </body>
</html>
