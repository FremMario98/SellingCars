<?php
  // Start Session
  session_start();
  // echo $_SESSION["currencarid"];
  $userid=$_SESSION["uid"];
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="Links\bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="Links\bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet"  type="text/css" href="css\animate.css" >
    <link rel="stylesheet" href="css\ViewMoreDetails.css">
<!-- Not All The jQuery Are Downloaded So We Put jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  </head>
  <body style="overflow:hidden;overflow-y:scroll;">

    <div class="col-md-1" id="sidebar">
      <div class="col-md-12 divitem">
        <a href="#"><i class="fas fa-angle-double-right itemicon"></i></a>
        <!-- <i class="fas fa-arrow-right"></i> -->
      </div>
      <div class="col-md-12" id="divprofileimage">
        <a href="#"><img src="Images\koenigsegg.jpg" id="profileimage"/></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="home.php"><i class="fas fa-home itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="Reservation\myreservation.php"><i class="fas fa-bookmark itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="cars.php"><i class="fas fa-car-alt itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="carbrands.php"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:100%;height:100%;"></a>
      </div>
      <div class="col-md-12 divitem">
        <a href="#" id="messageicon"><i class="far fa-comments itemicon"></i></a>
      </div>
      <div class="col-md-12 divitem" id="logoutbutton">
        <a href="index.php"><i class="fas fa-door-open itemicon"></i></a>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-light d-block d-sm-none navbarsidebar">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent2">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
              <a href="home.php"><i class="fas fa-home itemicon"></i> <span class="navbarforsidebar">Home</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><i class="fas fa-bookmark itemicon"></i> <span class="navbarforsidebar">Bookmark</span></a>
          </li>
          <li class="nav-item active">
            <a href="cars.php"><i class="fas fa-car-alt itemicon"></i> <span class="navbarforsidebar">View Cars</span></a>
          </li>
          <li class="nav-item active">
            <a href="#"><img src="https://cdn1.iconfinder.com/data/icons/startup-2/64/BRAND-512.png" style="width:40px;margin-top:15px;"> <span class="navbarforsidebar">Brands</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="freedommessageicon"><i class="far fa-comments itemicon"></i> <span class="navbarforsidebar">FreedomMessage</span></a>
          </li>
          <li class="nav-item active">
              <a href="#" id="logoutbutton"><i class="fas fa-door-open itemicon"></i> <span class="navbarforsidebar">Logout</span></a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="mycontainer col-md-10 col-10 offset-1 offset-md-1">

        <div class="col-md-7 col-12">
          <div class="col-md-11 col-12 offset-md-1 divcurruserprofile" >
            <img src="Images\koenigsegg.jpg" id="curruserprofimage"/>
          </div>
        </div>

        <div class="col-md-5 col-12 divcurruserprofile" id="divcurruserprofiledetails">

          <div class="col-md-12 col-12 sameheightelement" id="divcurrproffullname">
            <i class="fas fa-user"></i> <span id="currproffullname">Full Name</span>
          </div>

          <div class="col-md-12 col-12 sameheightelement">
            <i class="fas fa-at"></i> <span id="currprofusername">username</span>
          </div>

          <div class="col-md-12 col-12 sameheightelement">
            <i class="fas fa-phone"></i> <span id="currprofphone">+96174343243</span>
          </div>

          <div class="col-md-12 col-12 sameheightelement">
            <i class="fas fa-envelope"></i> <span id="currprofemail">Email@hotmail.com</span>
          </div>

        </div>

        <div class="col-md-11 offset-md-1 col-12 displayflex" id="buttonforeditprofile">
          <div class="col-md-5 offset-md-1 d-none d-md-block"></div>
          <button class="btn btn-primary col-md-5 col-8 offset-2 offset-md-1" data-toggle="modal" data-target="#exampleModalLong" id="editprofilebutton"><i class="fas fa-user-edit"></i>Edit</button>
        </div>

      </div>

      <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <label>First Name</label>
              <input id="modalfname" type="text" class="col-md-12 form-control"/>
              <label>Last Name</label>
              <input id="modallname" type="text" class="col-md-12 form-control"/>
              <label>Phone</label>
              <input id="modalphone" type="number" class="col-md-12 form-control"/>
              <label>Email</label>
              <input id="modalemail" type="email" class="col-md-12 form-control"/>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="savecuruserchange">Save changes</button>
              </div>
            </div>
          </div>
      </div>

      <div class="col-md-5" id="messagedialog">

      <div class="col-md-12 mainmessagedialogbox">
        <div class="col-md-12">
          <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
        <h3>Username</h3>
        <p>udfludsagfdlisfglasduifgaldsufgasdfgaliudfasifl<br/>ifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
        </div>
      </div>

      <div class="col-md-12 mainmessagedialogbox">
        <div class="col-md-12">
          <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
        <h3>Username</h3>
        <p>udfludsagfdlisfglasduifgaldsufgasdfgaliudfasifl<br/>ifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
        </div>
      </div>

      <div class="col-md-12 mainmessagedialogbox">
        <div class="col-md-12">
          <img src="Images\koenigsegg.jpg" class="imageofmessagedialog"/>
        <h3>Username</h3>
        <p>udfludsagfdlisfglasduifgaldsufgasdfgaliudfasifl<br/>ifugfdiuhsdiufgadipufgadsiupfgadsiupfgadspiu</p>
        </div>
      </div>

      </div>

<!-- <script src="js\viewprofile.js"></script> -->
<script type="text/javascript">

$(document).ready(function(){

  window.serverURL = "http://localhost/finalproject/server_side/ws/";
  var userexist='<?php echo isset($_SESSION["uid"]);?>';
  console.log(userexist);

  if(userexist.length==0){
    window.location="index.php";
  }
  else if(userexist.length==1){
    getCurrentUser();
  }


  $("#savecuruserchange").on("click",function(){
      updateCurrentUser();
  });

  function getCurrentUser(){

        var idstring='<?php echo isset($_SESSION["uid"]); ?>';
        if(idstring.length==0){
          window.location="index.php";
        }
        else if(idstring.length!=0){
            var id= '<?php echo $userid; ?>';
        }
        // alert(id);

        $.ajax({
          type: 'GET',
          url: window.serverURL+"ws_users.php",
          data: ({option :"10",id:id}),

          dataType: 'json',
          timeout: 5000,
          success: function(data, textStatus, xhr)
          {

            if(data==0)
              alert("Data couldn't be loaded!")
            else{
              data = JSON.parse(xhr.responseText);

              let fullname=$("#currproffullname").text(data[0].FirstName+" "+data[0].LastName);
              let phonenumber=$("#currprofphone").text(data[0].Phone);
              let email=$("#currprofemail").text(data[0].Email);
              let username=$("#currprofusername").text(data[0].Username);

              let firstnamemodal=$("#modalfname").val(data[0].FirstName);
              let lastnamemodal=$("#modallname").val(data[0].LastName);
              let phonenumbermodal=$("#modalphone").val(data[0].Phone);
              let emailmodal=$("#modalemail").val(data[0].Email);
              let usernamemodal=$("#exampleModalLongTitle").text(data[0].Username);

            }
          },
          error: function(xhr, status, errorThrown)
          {
            alert(status + errorThrown);
          }
        });  //

    }



function updateCurrentUser(){

      let idstring='<?php echo isset($_SESSION["uid"]); ?>';
      if(idstring.length==0){
        window.location="index.php";
      }
      else if(idstring.length!=0){
        var id='<?php echo $userid; ?>';
      }
      let firstname=$("#modalfname").val();
      let lastname=$("#modallname").val();
      let phonenumber=$("#modalphone").val();
      let email=$("#modalemail").val();

      $.ajax({
        type: 'GET',
        url: window.serverURL+"ws_users.php",
        // $_GET["id"], $_GET["firstName"], $_GET["lastName"], $_GET["phone"], $_GET["email"]
        data: ({option :"11",id:id,firstName:firstname,lastName:lastname,phone:phonenumber,email:email}),

        dataType: 'json',
        timeout: 5000,
        success: function(data, textStatus, xhr)
        {

          if(data==0)
            alert("Data couldn't be loaded!")
          else{
            data = JSON.parse(xhr.responseText);

            getCurrentUser(id);

          }
        },
        error: function(xhr, status, errorThrown)
        {
          alert(status + errorThrown);
        }
      });  //

  }


  $("#messageicon").on("click",function(){
  	if($("#messagedialog").css("right")=="-1300px")
  	{
      $("#messagedialog").css("right","0%");
      getComments();
  }
  	else{
  		$("#messagedialog").css("right","-1300px");
        $("#messagedialog").empty();
  	}

  });

  getComments();

  function getComments(){

        $.ajax({
          type: 'GET',
          url: window.serverURL+"ws_freedomreviews.php",
          data: ({option :"1"}),

          dataType: 'json',
          timeout: 5000,
          success: function(data, textStatus, xhr)
          {

            if(data<=0)
              alert("Data couldn't be loaded!")
            else{
              data = JSON.parse(xhr.responseText);

            populateComments(data);
            }
          },
          error: function(xhr, status, errorThrown)
          {
            alert(status + errorThrown);
          }
        });  //

    }

  function populateComments(data){

      var item;

      if(data.length>0){

         $.each(data, function(index, row) {

          item= `
          <div class="col-md-12 mainmessagedialogbox">
            <div class="col-md-12">
              <img src="Images\\koenigsegg.jpg" class="imageofmessagedialog"/>
            <h3>`+row.UserName+`</h3>
            <p>`+row.Comment+`</p>
            </div>
          </div>
          `;

        // $("#reviewscontainer").prepend(item);
        $("#messagedialog").prepend(item);

        });

      }
    }

    $("#logoutbutton").on("click",function(){
      logoutcurruser();
    });

    // Logout
    function logoutcurruser(){

    		  $.ajax({
    			  type: 'GET',
    			  url: window.serverURL+"ws_users.php",
    			  data: ({option :"9"}),

    			  dataType: 'json',
    			  timeout: 5000,
    			  success: function(data, textStatus, xhr)
    			  {

    				  if(data==0)
    					  alert("Data couldn't be loaded!")
    				  else{
    				        window.location.href="index.php";
    				  }
    			  },
    			  error: function(xhr, status, errorThrown)
    			  {
    				  alert(status + errorThrown);
    			  }
    		  });  //

    	}

});

$("#freedommessageicon").on("click",function(){
  window.location.href="Reviews@ndComments\\comment.php";
});

</script>
  </body>
</html>
